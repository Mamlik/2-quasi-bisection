import QuasiBisection
import QuasiBisection.MainTheorem

example (n : ℕ) : n + 0 = n := by simp
example (x : ℤ) : x + 0 = x := by simp
example : (2 : ℕ) + 2 = 4 := by decide
example (a b : Bool) : a = b ∨ a ≠ b := by cases a <;> cases b <;> simp
#print axioms QuasiBisection.exists_balanced_iff
#check QuasiBisection.CubicQuasiBisectionStatement
#print axioms QuasiBisection.BoundaryModel.repair_wellFounded
#print axioms QuasiBisection.BoundaryModel.single_repair_trace
#print axioms QuasiBisection.BoundaryModel.single_repair
#print axioms QuasiBisection.BoundaryModel.boundaryProfiles
#print axioms QuasiBisection.BoundaryModel.boundaryBridge

#print axioms QuasiBisection.BridgeCut.ofIsBridge
#print axioms QuasiBisection.BridgeCut.connected_induce
#print axioms QuasiBisection.BridgeCut.goodEquivJoint
#print axioms QuasiBisection.BridgeCut.jointWeight_goodEquivJoint
#print axioms QuasiBisection.BridgeCut.spectralStep
#print axioms QuasiBisection.BoundaryModel.forest_step_four
#print axioms QuasiBisection.BoundaryModel.forest_step_two

#print axioms QuasiBisection.BoundaryModel.repair_zero_weight
#print axioms QuasiBisection.BoundaryModel.deleteVertex_degree
#print axioms QuasiBisection.BoundaryModel.extendAt_sum
#print axioms QuasiBisection.BoundaryModel.change_two_inputs
#print axioms QuasiBisection.BoundaryModel.fixed_sign_walk

#print axioms QuasiBisection.BoundaryModel.open_cycle_step
#print axioms QuasiBisection.acyclic_delete_of_degree_le_two
#print axioms QuasiBisection.BoundaryModel.cycle_step_four
#print axioms QuasiBisection.BoundaryModel.cactus_step_four
#print axioms QuasiBisection.cactusCycles_of_no_even_cycle
#print axioms QuasiBisection.exists_even_packing_cactus

#print axioms QuasiBisection.BoundaryModel.cactus_forest_step_four
#print axioms QuasiBisection.residueModel_degree
#print axioms QuasiBisection.residueModel_sum
#print axioms QuasiBisection.exists_residue_coloring
#print axioms QuasiBisection.residue_step_four
#print axioms QuasiBisection.packing_change_exterior
#print axioms QuasiBisection.packing_even_leftover
#print axioms QuasiBisection.imbalance_even

#print axioms QuasiBisection.BoundaryModel.repair_among_defects
#print axioms QuasiBisection.BoundaryModel.repair_two_edges
#print axioms QuasiBisection.CycleOrder.prefix_imbalance
#print axioms QuasiBisection.EvenPacking.finish_partial
#print axioms QuasiBisection.EvenPacking.finish_settled
#print axioms QuasiBisection.cubic_quasi_bisection
#print axioms QuasiBisection.cubic_quasi_bisection_classes

#print axioms QuasiBisection.subcubic_quasi_bisection
#print axioms QuasiBisection.subcubic_quasi_bisection_classes
