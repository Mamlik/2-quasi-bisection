module

public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Data.Fintype.Prod
public import Mathlib.Data.Fintype.Card

/-! # Eliminating the centres of disjoint three-vertex paths

A group is a list of incident base vertices. Repeated endpoints are allowed and
retain one colour. Only centres shared by distinct required groups are forbidden.
-/

@[expose] public section

namespace QuasiBisection

/-- The Boolean coordinate selects the left or right endpoint of a path. -/
abbrev Endpoint (n : ℕ) := Fin n × Bool

/-- The two summands distinguish endpoints from centres. -/
abbrev Vertex (n : ℕ) := Sum (Endpoint n) (Fin n)

/-- A path has a mixed triple of colours. -/
def PathNAE (a c b : Bool) : Prop := ¬ (a = c ∧ b = c)

theorem pathNAE_iff_monoDegree_le_one (a c b : Bool) :
    PathNAE a c b ↔ (if a = c then 1 else 0) + (if b = c then 1 else 0) ≤ (1 : ℕ) := by
  unfold PathNAE
  cases a <;> cases c <;> cases b <;> decide

theorem pathNAE_iff_free_or_forced (a c b : Bool) :
    PathNAE a c b ↔ a ≠ b ∨ c = !a := by
  unfold PathNAE
  cases a <;> cases c <;> cases b <;> decide

variable {n m : ℕ}

/-- One colour for each base vertex, even when its label occurs twice in a group. -/
def colour (x : Endpoint n → Bool) (c : Fin n → Bool) : Vertex n → Bool := Sum.elim x c

/-- An incidence list contains vertices with different colours. -/
def Mixed (g : List (Vertex n)) (h : Vertex n → Bool) : Prop :=
  ∃ u ∈ g, ∃ v ∈ g, h u ≠ h v

theorem mixed_of_subset {g g' : List (Vertex n)} {h : Vertex n → Bool}
    (hsub : ∀ u ∈ g, u ∈ g') (hm : Mixed g h) : Mixed g' h := by
  obtain ⟨u, hu, v, hv, huv⟩ := hm
  exact ⟨u, hsub _ hu, v, hsub _ hv, huv⟩

theorem mixed_double_pair_iff (u v : Vertex n) (h : Vertex n → Bool) :
    Mixed [u, u, v, v] h ↔ h u ≠ h v := by
  constructor
  · rintro ⟨p, hp, q, hq, hne⟩
    simp only [List.mem_cons, List.not_mem_nil, or_false, or_self] at hp hq
    rcases hp with rfl | rfl | rfl <;> rcases hq with rfl | rfl | rfl <;> grind
  · intro huv
    exact ⟨u, by simp, v, by simp, huv⟩

/-- Number of positively coloured endpoints. -/
def positiveCount (x : Endpoint n → Bool) : ℕ := (Finset.univ.filter fun e => x e = true).card

/-- The sum whose negative is the imbalance in the graph gluing formula. -/
def endpointSum (x : Endpoint n → Bool) : ℤ := ∑ e, if x e = true then 1 else -1

theorem endpointSum_eq (x : Endpoint n → Bool) :
    endpointSum x = 2 * (positiveCount x : ℤ) - 2 * (n : ℤ) := by
  have h (e : Endpoint n) : (if x e = true then 1 else -1 : ℤ) =
      2 * (if x e = true then 1 else 0) - 1 := by cases x e <;> decide
  simp only [endpointSum, h, Finset.sum_sub_distrib, ← Finset.mul_sum, Finset.sum_boole]
  simp [positiveCount, Fintype.card_prod, mul_comm]

theorem endpointSum_eq_zero_iff (x : Endpoint n → Bool) :
    endpointSum x = 0 ↔ positiveCount x = n := by
  rw [endpointSum_eq]
  omega

/-- Each path has unequal endpoints or its centre has the unique permitted sign. -/
def PathValid (x : Endpoint n → Bool) (c : Fin n → Bool) : Prop :=
  ∀ i, PathNAE (x (i, false)) (c i) (x (i, true))

/-- Signs assigned to forced centres extend canonically to all centres. -/
def defaultCentre (x : Endpoint n → Bool) (i : Fin n) : Bool := !x (i, false)

private theorem default_valid (x : Endpoint n → Bool) : PathValid x (defaultCentre x) :=
  fun _ => (pathNAE_iff_free_or_forced ..).2 (Or.inr rfl)

/-- Membership is by label, so two occurrences of one endpoint never witness mixedness. -/
def CompactGroup (x : Endpoint n → Bool) (g : List (Vertex n)) : Prop :=
  Mixed g (colour x (defaultCentre x)) ∨
    ∃ i, Sum.inr i ∈ g ∧ x (i, false) ≠ x (i, true) ∧ ∃ v ∈ g, v ≠ Sum.inr i

private theorem mixed_congr {g : List (Vertex n)} {h k : Vertex n → Bool}
    (heq : ∀ u ∈ g, h u = k u) (hm : Mixed g h) : Mixed g k := by
  obtain ⟨u, hu, v, hv, huv⟩ := hm
  exact ⟨u, hu, v, hv, by rwa [← heq u hu, ← heq v hv]⟩

/-- A free centre can be changed against any *distinct* vertex in its group. -/
theorem exists_mixed_iff_compactGroup (x : Endpoint n → Bool) (g : List (Vertex n)) :
    (∃ c, PathValid x c ∧ Mixed g (colour x c)) ↔ CompactGroup x g := by
  classical
  constructor
  · rintro ⟨c, hc, hm⟩
    by_cases hfree : ∃ i, Sum.inr i ∈ g ∧ x (i, false) ≠ x (i, true)
    · obtain ⟨i, hi, hne⟩ := hfree
      refine Or.inr ⟨i, hi, hne, ?_⟩
      obtain ⟨u, hu, v, hv, huv⟩ := hm
      by_cases hui : u = Sum.inr i
      · exact ⟨v, hv, fun hvi => huv (congrArg _ (hui.trans hvi.symm))⟩
      · exact ⟨u, hu, hui⟩
    · apply Or.inl
      apply mixed_congr (h := colour x c) _ hm
      intro u hu
      cases u with
      | inl e => rfl
      | inr i =>
        exact ((pathNAE_iff_free_or_forced ..).1 (hc i)).resolve_left
          (fun hne => hfree ⟨i, hu, hne⟩)
  · rintro (hm | ⟨i, hi, hfree, v, hv, hvi⟩)
    · exact ⟨defaultCentre x, default_valid x, hm⟩
    · let b := colour x (defaultCentre x) v
      let c (j : Fin n) := if j = i then !b else defaultCentre x j
      have hc : PathValid x c := by
        intro j
        apply (pathNAE_iff_free_or_forced ..).2
        by_cases hji : j = i
        · subst j
          exact Or.inl hfree
        · exact Or.inr (ite_eq_right hji)
      have hv' : colour x c v = b := by
        cases v with
        | inl e => rfl
        | inr j =>
          exact ite_eq_right (fun hji => hvi (congrArg Sum.inr hji))
      refine ⟨c, hc, Sum.inr i, hi, v, hv, ?_⟩
      rw [hv']
      change (if i = i then !b else _) ≠ b
      simp

/-- The incidence lists of distinct required groups share no centre. -/
def UniqueGroup (groups : Fin m → List (Vertex n)) : Prop :=
  ∀ i j k, Sum.inr i ∈ groups j → Sum.inr i ∈ groups k → j = k

/-- Elimination at fixed endpoints: patch the local colourings using unique group ownership. -/
theorem exists_centres_iff (groups : Fin m → List (Vertex n)) (unique : UniqueGroup groups)
    (x : Endpoint n → Bool) :
    (∃ c, PathValid x c ∧ ∀ j, Mixed (groups j) (colour x c)) ↔
      ∀ j, CompactGroup x (groups j) := by
  classical
  constructor
  · rintro ⟨c, hc, hgroups⟩ j
    exact (exists_mixed_iff_compactGroup ..).1 ⟨c, hc, hgroups j⟩
  · intro hgroups
    have hlocal := fun j => (exists_mixed_iff_compactGroup ..).2 (hgroups j)
    choose localCentre hvalid hmixed using hlocal
    let c (i : Fin n) := if h : ∃ j, Sum.inr i ∈ groups j then localCentre h.choose i
      else defaultCentre x i
    refine ⟨c, ?_, ?_⟩
    · intro i
      by_cases h : ∃ j, Sum.inr i ∈ groups j
      · simpa [c, h] using hvalid h.choose i
      · simpa [c, h] using default_valid x i
    · intro j
      apply mixed_congr (h := colour x (localCentre j)) _ (hmixed j)
      intro u hu
      cases u with
      | inl e => rfl
      | inr i =>
        have h : ∃ k, Sum.inr i ∈ groups k := ⟨j, hu⟩
        change localCentre j i = c i
        simp [c, h, unique i h.choose j h.choose_spec hu]

/-- Exactly balanced complete colourings exist precisely for the endpoint-only formulation. -/
theorem exists_balanced_iff (groups : Fin m → List (Vertex n)) (unique : UniqueGroup groups) :
    (∃ x c, endpointSum x = 0 ∧ PathValid x c ∧ ∀ j, Mixed (groups j) (colour x c)) ↔
      ∃ x, positiveCount x = n ∧ ∀ j, CompactGroup x (groups j) := by
  constructor
  · rintro ⟨x, c, hx, hc, hg⟩
    exact ⟨x, (endpointSum_eq_zero_iff x).1 hx, (exists_centres_iff groups unique x).1 ⟨c, hc, hg⟩⟩
  · rintro ⟨x, hx, hg⟩
    obtain ⟨c, hc, hm⟩ := (exists_centres_iff groups unique x).2 hg
    exact ⟨x, c, (endpointSum_eq_zero_iff x).2 hx, hc, hm⟩

end QuasiBisection
