module

public import QuasiBisection.Basic
public import Mathlib.Logic.Relation

/-! Two sides of a cut bridge interact only through their root colours. -/

@[expose] public section

namespace QuasiBisection.Bridge

inductive Port where
  | fixed (colour : Bool)
  | opposite (marked : Bool)

def Port.output : Port → Bool → Bool
  | .fixed c, _ => c
  | .opposite _, t => !t

/-- Change in the retained root's weighted contribution after contraction. -/
def Port.offset : Port → Bool → ℤ
  | .opposite true, t => -spin t
  | _, _ => 0

theorem compatible (p q : Port) :
    ∃ a b, p.output b = a ∧ q.output a = b := by
  cases p with
  | fixed c => exact ⟨c, q.output c, rfl, rfl⟩
  | opposite m =>
    cases q with
    | fixed c => exact ⟨!c, c, rfl, rfl⟩
    | opposite n => exact ⟨true, false, rfl, rfl⟩

structure Side (X : Type*) where
  root : X → Bool
  valid : X → Bool → Prop
  weight : X → ℤ

variable {X Y : Type*}

structure Profile (A : Side X) where
  port : Port
  row : Bool → X
  allowed : ∀ t, A.valid (row t) t
  root_eq : ∀ t, A.root (row t) = port.output t
  constant : ℤ
  weight_eq : ∀ t, A.weight (row t) = constant + port.offset t

def ProfileThrough (A : Side X) : Prop :=
  ∀ x t, A.valid x t → ∃ p : Profile A, p.row t = x

abbrev Reduced (A : Side X) (p : Port) :=
  {x : X // A.valid x (p.output (A.root x))}

def reducedWeight (A : Side X) (p : Port) (x : Reduced A p) : ℤ :=
  A.weight x.val + p.offset (A.root x.val)

abbrev Joint (A : Side X) (B : Side Y) :=
  {z : X × Y // A.valid z.1 (B.root z.2) ∧ B.valid z.2 (A.root z.1)}

def jointWeight (A : Side X) (B : Side Y) (z : Joint A B) : ℤ :=
  A.weight z.val.1 + B.weight z.val.2

def liftRight (A : Side X) (B : Side Y) (p : Profile A) (y : Reduced B p.port) :
    Joint A B :=
  ⟨(p.row (B.root y.val), y.val), p.allowed _, by rw [p.root_eq]; exact y.property⟩

def liftLeft (A : Side X) (B : Side Y) (q : Profile B) (x : Reduced A q.port) :
    Joint A B :=
  ⟨(x.val, q.row (A.root x.val)), by rw [q.root_eq]; exact x.property, q.allowed _⟩

def Walk {Z : Type*} (L : ℕ) (w : Z → ℤ) (a b : Z) : Prop :=
  Relation.ReflTransGen (fun x y => (w y - w x).natAbs ≤ L) a b

def HasStep {Z : Type*} (L : ℕ) (w : Z → ℤ) : Prop := ∀ a b, Walk L w a b

private theorem liftWalk {L : ℕ} {w : X → ℤ} {v : Y → ℤ} (f : X → Y) (c : ℤ)
    (shift : ∀ x, v (f x) = c + w x) {a b : X} (h : Walk L w a b) :
    Walk L v (f a) (f b) := by
  apply Relation.ReflTransGen.lift (r := fun x y => (w y - w x).natAbs ≤ L) f _ a b h
  intro x y hxy
  change (v (f y) - v (f x)).natAbs ≤ L
  rw [shift, shift]
  have eq : c + w y - (c + w x) = w y - w x := by omega
  rw [eq]
  exact hxy

/-- Profiles may be chosen anew for each endpoint of the walk. -/
theorem bridgeGluing (A : Side X) (B : Side Y) (L : ℕ)
    (profilesA : ProfileThrough A) (profilesB : ProfileThrough B)
    (stepA : ∀ p, HasStep L (reducedWeight A p))
    (stepB : ∀ p, HasStep L (reducedWeight B p)) :
    HasStep L (jointWeight A B) := by
  intro f g
  obtain ⟨p, hp⟩ := profilesA _ _ f.property.1
  obtain ⟨q, hq⟩ := profilesB _ _ g.property.2
  obtain ⟨a, b, ha, hb⟩ := compatible p.port q.port
  have rootA : A.root (p.row b) = a := (p.root_eq b).trans ha
  have rootB : B.root (q.row a) = b := (q.root_eq a).trans hb
  let y₀ : Reduced B p.port := ⟨f.val.2, by rw [← p.root_eq, hp]; exact f.property.2⟩
  let y₁ : Reduced B p.port := ⟨q.row a, by rw [rootB, ha]; exact q.allowed a⟩
  let x₀ : Reduced A q.port := ⟨p.row b, by rw [rootA, hb]; exact p.allowed b⟩
  let x₁ : Reduced A q.port := ⟨g.val.1, by rw [← q.root_eq, hq]; exact g.property.1⟩
  have right := liftWalk (liftRight A B p) p.constant (v := jointWeight A B)
    (fun y => by simp only [jointWeight, liftRight, reducedWeight, p.weight_eq]; omega)
    (stepB p.port y₀ y₁)
  have left := liftWalk (liftLeft A B q) q.constant (v := jointWeight A B)
    (fun x => by simp only [jointWeight, liftLeft, reducedWeight, q.weight_eq]; omega)
    (stepA q.port x₀ x₁)
  have startEq : liftRight A B p y₀ = f := Subtype.ext (Prod.ext hp rfl)
  have midEq : liftRight A B p y₁ = liftLeft A B q x₀ := by
    apply Subtype.ext
    exact Prod.ext (congrArg p.row rootB) (congrArg q.row rootA).symm
  have endEq : liftLeft A B q x₁ = g := Subtype.ext (Prod.ext rfl hq)
  rw [startEq, midEq] at right
  rw [endEq] at left
  exact right.trans left

end QuasiBisection.Bridge
