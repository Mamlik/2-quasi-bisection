module

public import QuasiBisection.Boundary
public import Mathlib.Logic.Relation

/-! A natural-valued potential for actual flips in a finite boundary model. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

variable {V : Type*} [Fintype V] (M : BoundaryModel V)

noncomputable def edgeHit (h : V → Bool) (v u : V) : ℕ := by
  classical
  exact if M.graph.Adj v u then same (h v) (h u) else 0

theorem hit_symm (h : V → Bool) (v u : V) :
    M.edgeHit h v u = M.edgeHit h u v := by
  classical
  unfold edgeHit same
  rw [M.graph.adj_comm v u]
  cases h v <;> cases h u <;> rfl

/-- Twice the number of monochromatic edges internal to the set, plus twice
the number of matching fixed slots in the set. Opposite slots never match. -/
noncomputable def energyOn (h : V → Bool) (s : Finset V) : ℕ :=
  ∑ v ∈ s, ((∑ u ∈ s, M.edgeHit h v u) + 2 * M.fixed v (h v))

private theorem energy_insert [DecidableEq V] (h : V → Bool) (s : Finset V) (r : V)
    (hr : r ∉ s) :
    M.energyOn h (insert r s) =
      M.energyOn h s + 2 * ((∑ u ∈ s, M.edgeHit h r u) + M.fixed r (h r)) := by
  classical
  have hd : M.edgeHit h r r = 0 := by simp [edgeHit]
  simp only [energyOn, Finset.sum_insert hr, hd, Nat.zero_add]
  have split : (∑ v ∈ s, ((M.edgeHit h v r + ∑ u ∈ s, M.edgeHit h v u) +
      2 * M.fixed v (h v))) =
      (∑ v ∈ s, M.edgeHit h r v) +
      ∑ v ∈ s, ((∑ u ∈ s, M.edgeHit h v u) + 2 * M.fixed v (h v)) := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro v _
    rw [M.hit_symm h v r, Nat.add_assoc]
  rw [split]
  omega

private theorem energy_remove [DecidableEq V] (h : V → Bool) (r : V) :
    M.energyOn h Finset.univ =
      M.energyOn h (Finset.univ.erase r) + 2 * M.monoDegree h r := by
  classical
  have he := M.energy_insert h (Finset.univ.erase r) r (Finset.notMem_erase r _)
  rw [Finset.insert_erase (Finset.mem_univ r)] at he
  have hd : M.edgeHit h r r = 0 := by simp [edgeHit]
  have hi : M.inside h r = ∑ u, M.edgeHit h r u := by
    simp only [inside, neighbors, Finset.sum_filter, edgeHit]
  simpa only [monoDegree, hi, Finset.sum_erase _ hd] using he

theorem energy_flip (h : V → Bool) (r : V) :
    M.energyOn (flip h r) Finset.univ + 2 * M.monoDegree h r =
      M.energyOn h Finset.univ + 2 * M.monoDegree (flip h r) r := by
  classical
  have outside : M.energyOn (flip h r) (Finset.univ.erase r) =
      M.energyOn h (Finset.univ.erase r) := by
    apply Finset.sum_congr rfl
    intro v hv
    have ev := Finset.ne_of_mem_erase hv
    congr 1
    · apply Finset.sum_congr rfl
      intro u hu
      simp only [edgeHit, flip, ite_eq_right ev, ite_eq_right (Finset.ne_of_mem_erase hu)]
    · simp only [flip, ite_eq_right ev]
  rw [M.energy_remove (flip h r) r, M.energy_remove h r, outside]
  omega

theorem energy_decreases (h : V → Bool) (r : V) (bad : 2 ≤ M.monoDegree h r) :
    M.energyOn (flip h r) Finset.univ < M.energyOn h Finset.univ := by
  have := M.energy_flip h r
  have := M.flip_root h r
  omega

def RepairStep (h g : V → Bool) : Prop := ∃ r, 2 ≤ M.monoDegree h r ∧ g = flip h r

/-- Every choice of a defect strictly decreases the same natural number. -/
theorem repair_wellFounded : WellFounded (fun g h => M.RepairStep h g) := by
  apply Subrelation.wf (r := (fun g h => M.energyOn g Finset.univ < M.energyOn h Finset.univ))
  · rintro g h ⟨r, hr, rfl⟩
    exact M.energy_decreases h r hr
  · exact (measure (fun h => M.energyOn h Finset.univ)).wf

theorem repair_exists (h : V → Bool) : ∃ g,
    Relation.ReflTransGen M.RepairStep h g ∧ ∀ v, M.monoDegree g v ≤ 1 := by
  classical
  induction h using M.repair_wellFounded.induction with
  | h h ih =>
    by_cases good : ∀ v, M.monoDegree h v ≤ 1
    · exact ⟨h, .refl, good⟩
    · obtain ⟨r, hr⟩ := Classical.not_forall.mp good
      have step : M.RepairStep h (flip h r) := ⟨r, by omega, rfl⟩
      obtain ⟨g, walk, hg⟩ := ih _ step
      exact ⟨g, walk.head step, hg⟩

end QuasiBisection.BoundaryModel
