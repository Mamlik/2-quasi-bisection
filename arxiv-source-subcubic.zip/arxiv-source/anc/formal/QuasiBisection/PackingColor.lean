module

public import QuasiBisection.CycleOrder
public import QuasiBisection.PackingBoundary

/-! Coordinates and sum of colors during an inversion of packed cycles. -/

@[expose] public section

namespace QuasiBisection

open CycleOrder BoundaryModel

variable {V : Type*} {G : SimpleGraph V} {F : Finset (Finset V)}

namespace EvenPacking

variable (P : EvenPacking G F)

noncomputable def order (T : F) := CycleOrder.ofSupport (P.1 T.val T.property)

abbrev Position := Σ T : F, Fin (P.order T).size

noncomputable def atPos (p : P.Position) : V := ((P.order p.1).vertex p.2).val

theorem atPos_mem (p : P.Position) : P.atPos p ∈ p.1.val :=
  ((P.order p.1).vertex p.2).property

theorem atPos_injective : Function.Injective P.atPos := by
  intro ⟨S, i⟩ ⟨T, j⟩ eq
  have sameSet : S = T := by
    by_contra ne
    exact Finset.disjoint_left.mp (P.2 S.property T.property (fun e => ne (Subtype.ext e)))
      (P.atPos_mem ⟨S, i⟩) (eq ▸ P.atPos_mem ⟨T, j⟩)
  subst T
  exact congrArg (Sigma.mk S) ((P.order S).vertex.injective (Subtype.ext eq))

theorem atPos_not_leftover (p : P.Position) : P.atPos p ∉ leftover F :=
  fun h => h _ p.1.property (P.atPos_mem p)

noncomputable def coordinates : (leftover F ⊕ P.Position) ≃ V := by
  classical
  refine Equiv.ofBijective (Sum.elim Subtype.val P.atPos) ⟨?_, ?_⟩
  · rintro (u | p) (v | q) eq
    · exact congrArg Sum.inl (Subtype.ext eq)
    · change u.val = P.atPos q at eq
      exact (P.atPos_not_leftover q (eq ▸ u.property)).elim
    · change P.atPos p = v.val at eq
      exact (P.atPos_not_leftover p (eq.symm ▸ v.property)).elim
    · exact congrArg Sum.inr (P.atPos_injective eq)
  · intro v
    by_cases hv : v ∈ leftover F
    · exact ⟨.inl ⟨v, hv⟩, rfl⟩
    change ¬ ∀ T ∈ F, v ∉ T at hv
    push Not at hv
    obtain ⟨S, hS, hv⟩ := hv
    let T : F := ⟨S, hS⟩
    let u : T.val := ⟨v, hv⟩
    exact ⟨.inr ⟨T, (P.order T).vertex.symm u⟩,
      congrArg Subtype.val ((P.order T).vertex.apply_symm_apply u)⟩

@[simp] theorem coordinates_left (w : leftover F) : P.coordinates (.inl w) = w.val := rfl
@[simp] theorem coordinates_right (p : P.Position) : P.coordinates (.inr p) = P.atPos p := rfl

/-- k records the prefix length on each packed cycle. -/
noncomputable def coloring (k : F → ℕ) (r : leftover F → Bool) (v : V) : Bool :=
  Sum.elim r (fun p : P.Position => prefixColor (k p.1) p.2.val) (P.coordinates.symm v)

@[simp] theorem coloring_left (k : F → ℕ) (r : leftover F → Bool) (w : leftover F) :
    P.coloring k r w.val = r w := by
  unfold coloring
  rw [← P.coordinates_left w, Equiv.symm_apply_apply]
  rfl

@[simp] theorem coloring_right (k : F → ℕ) (r : leftover F → Bool) (p : P.Position) :
    P.coloring k r (P.atPos p) = prefixColor (k p.1) p.2.val := by
  unfold coloring
  rw [← P.coordinates_right p, Equiv.symm_apply_apply]
  rfl

open Classical in
theorem coloring_sum [Fintype V] (k : F → ℕ) (r : leftover F → Bool) :
    imbalance (P.coloring k r) = imbalance r +
      ∑ T : F, (if min (k T) (P.order T).size % 2 = 0 then 0 else -2) := by
  classical
  unfold imbalance
  rw [← P.coordinates.sum_comp, Fintype.sum_sum_type, Fintype.sum_sigma]
  simp only [coordinates_left, coloring_left, coordinates_right, coloring_right]
  exact congrArg (_ + ·) (Finset.sum_congr rfl (fun T _ => prefix_imbalance (P.order T).even _))

def Settled (k : F → ℕ) (T : F) : Prop := k T = 0 ∨ k T = (P.order T).size

theorem settled_contribution {k : F → ℕ} {T : F} (settled : P.Settled k T) :
    (if min (k T) (P.order T).size % 2 = 0 then (0 : ℤ) else -2) = 0 := by
  obtain ⟨m, hm⟩ := (P.order T).even
  rcases settled with h | h <;> simp [h, show (P.order T).size % 2 = 0 by omega]

end EvenPacking
end QuasiBisection
