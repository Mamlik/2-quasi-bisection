module

public import QuasiBisection.BoundaryProfiles

/-! Contraction at a real boundary slot preserves the step bound. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

open Bridge

variable {V W : Type*} [Fintype V] [Fintype W] (M : BoundaryModel V)

noncomputable def markSlot (r : V) (free : M.marked r < M.opposite r) :
    BoundaryModel V := by
  classical
  exact { M with
    marked := fun v => M.marked v + if v = r then 1 else 0
    marked_le := by
      intro v
      by_cases e : v = r
      · subst v; simp only [↓reduceIte]; omega
      · simpa [e] using M.marked_le v }

noncomputable def contract (r : V) (free : M.marked r < M.opposite r) :
    Port → BoundaryModel V
  | .fixed t => M.fill r free t
  | .opposite false => M
  | .opposite true => M.markSlot r free

abbrev Good (N : BoundaryModel V) := {h : V → Bool // ∀ v, N.monoDegree h v ≤ 1}

theorem contract_valid (r : V) (free : M.marked r < M.opposite r) (p : Port) (h : V → Bool) :
    (M.cutSide r).asSide.valid h (p.output (h r)) ↔
      ∀ v, (M.contract r free p).monoDegree h v ≤ 1 := by
  cases p with
  | fixed t => exact M.fill_valid r free h t
  | opposite m =>
    have opposite : h r ≠ !(h r) := by cases h r <;> decide
    change ((∀ v, v ≠ r → M.monoDegree h v ≤ 1) ∧
      M.monoDegree h r + (if h r = !(h r) then 1 else 0) ≤ 1) ↔ _
    simp only [ite_eq_right opposite, Nat.add_zero]
    have sameDegree : ∀ v, (M.contract r free (.opposite m)).monoDegree h v = M.monoDegree h v :=
      fun v => by cases m <;> rfl
    simp only [sameDegree]
    constructor
    · rintro ⟨elsewhere, root⟩ v
      by_cases e : v = r
      · simpa [e] using root
      · exact elsewhere v e
    · exact fun all => ⟨fun v _ => all v, all r⟩

theorem contract_weight (r : V) (free : M.marked r < M.opposite r) (p : Port) (h : V → Bool) :
    (M.contract r free p).weightedSum h = M.weightedSum h + p.offset (h r) := by
  classical
  cases p with
  | fixed t => exact (Int.add_zero _).symm
  | opposite m =>
    cases m with
    | false => exact (Int.add_zero _).symm
    | true =>
      let N := M.markSlot r free
      have outside : (∑ v ∈ Finset.univ.erase r, N.weight v * spin (h v)) =
          ∑ v ∈ Finset.univ.erase r, M.weight v * spin (h v) := by
        apply Finset.sum_congr rfl
        intro v hv
        simp [N, weight, markSlot, Finset.ne_of_mem_erase hv]
      have atRoot : N.weight r = M.weight r - 1 := by simp [N, weight, markSlot]
      change N.weightedSum h = M.weightedSum h + -spin (h r)
      unfold weightedSum
      rw [← Finset.add_sum_erase _ _ (Finset.mem_univ r),
        ← Finset.add_sum_erase _ (fun v => M.weight v * spin (h v)) (Finset.mem_univ r), outside,
        atRoot, Int.sub_mul, Int.one_mul]
      omega

def spectralStep (M : BoundaryModel V) (L : ℕ) : Prop :=
  HasStep L (fun h : Good M => M.weightedSum h.val)

private theorem reducedStep (r : V) (free : M.marked r < M.opposite r) (p : Port) (L : ℕ)
    (step : (M.contract r free p).spectralStep L) :
    HasStep L (reducedWeight (M.cutSide r).asSide p) := by
  let toGood (x : Reduced (M.cutSide r).asSide p) : Good (M.contract r free p) :=
    ⟨x.val, (M.contract_valid r free p x.val).1 x.property⟩
  let back (x : Good (M.contract r free p)) : Reduced (M.cutSide r).asSide p :=
    ⟨x.val, (M.contract_valid r free p x.val).2 x.property⟩
  intro x y
  apply Relation.ReflTransGen.lift (r := fun a b : Good (M.contract r free p) =>
    ((M.contract r free p).weightedSum b.val - (M.contract r free p).weightedSum a.val).natAbs ≤ L)
    back _ (toGood x) (toGood y) (step _ _)
  intro a b hab
  change ((M.contract r free p).weightedSum b.val - (M.contract r free p).weightedSum a.val).natAbs
    ≤ L at hab
  rw [M.contract_weight, M.contract_weight] at hab
  exact hab

/-- Bridge gluing for actual boundary models, with just the two smaller
spectral bounds as induction premises. The whole colouring is a compatible
pair of side colourings. -/
theorem boundaryBridge (N : BoundaryModel W) (r : V) (s : W)
    (freeR : M.marked r < M.opposite r) (freeS : N.marked s < N.opposite s) (L : ℕ)
    (left : ∀ p, (M.contract r freeR p).spectralStep L)
    (right : ∀ p, (N.contract s freeS p).spectralStep L) :
    HasStep L (jointWeight (M.cutSide r).asSide (N.cutSide s).asSide) :=
  bridgeGluing _ _ L (M.boundaryProfiles r freeR) (N.boundaryProfiles s freeS)
    (fun p => M.reducedStep r freeR p L (left p))
    (fun p => N.reducedStep s freeS p L (right p))

end QuasiBisection.BoundaryModel
