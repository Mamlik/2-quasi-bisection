module

public import QuasiBisection.VertexDeletion

/-! Repairing temporary colorings obtained by opening a cycle at one vertex. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

open Bridge

variable {V : Type*} [Fintype V] (M : BoundaryModel V) (r : V)

open Classical in
private theorem repair_extension (s : Bool) (f : Good (M.deleteVertex r (fun _ => s))) :
    let h := extendAt r s f.val
    ∃ g : Good M, ((∀ v, M.monoDegree h v ≤ 1) → g.val = h) ∧
      (M.weightedSum g.val = M.weightedSum h ∨
        (M.weight r ≠ 0 ∧ M.weightedSum g.val = M.weightedSum h - 2 * spin s)) := by
  let h := extendAt r s f.val
  change ∃ g : Good M, _ ∧ (_ ∨ (_ ∧ _))
  by_cases ok : ∀ v, M.monoDegree h v ≤ 1
  · exact ⟨⟨h, ok⟩, fun _ => rfl, Or.inl rfl⟩
  have rest (v : V) (ne : v ≠ r) : M.monoDegree h v ≤ 1 :=
    (M.extendAt_degree r s f.val ⟨v, ne⟩).le.trans (f.property ⟨v, ne⟩)
  have bad : 2 ≤ M.monoDegree h r := by
    by_contra! good
    exact ok (fun v => by
      by_cases e : v = r
      · simpa [e] using (show M.monoDegree h r ≤ 1 by omega)
      · exact rest v e)
  by_cases zero : M.weight r = 0
  · obtain ⟨valid, eq⟩ := M.repair_zero_weight h r zero bad rest
    exact ⟨⟨flip h r, valid⟩, fun impossible => (ok impossible).elim, Or.inl eq⟩
  · obtain ⟨g, _, valid, _, delta⟩ := M.single_repair h r bad rest
    exact ⟨⟨g, valid⟩, fun impossible => (ok impossible).elim,
      delta.imp_right (fun eq => ⟨zero, by simpa [h] using eq⟩)⟩

private theorem corrected_step (s : Bool) (c a b x y : ℤ)
    (near : (b - a).natAbs ≤ 2)
    (dx : x = c + a ∨ x = c + a - 2 * spin s)
    (dy : y = c + b ∨ y = c + b - 2 * spin s) : (y - x).natAbs ≤ 4 := by
  cases s <;> simp [spin] at dx dy <;> omega

open Classical in
/-- At fixed root sign each forest walk lifts to a walk on the full graph.
A zero-weight root costs nothing. With nonzero weight, the two possible
corrections differ by two, so a path step of two still gives four. -/
theorem fixed_sign_walk (s : Bool)
    (forest : (M.graph.induce {v | v ≠ r}).IsAcyclic)
    (small : M.weight r ≠ 0 → ∀ v : Away r,
      M.marked v.val + (neighbors (M.graph.induce {v | v ≠ r}) v).card ≤ 2)
    (f g : Good (M.deleteVertex r (fun _ => s))) :
    ∃ a b : Good M,
      Walk 4 (fun h : Good M => M.weightedSum h.val) a b ∧
      ((∀ v, M.monoDegree (extendAt r s f.val) v ≤ 1) → a.val = extendAt r s f.val) ∧
      ((∀ v, M.monoDegree (extendAt r s g.val) v ≤ 1) → b.val = extendAt r s g.val) ∧
      (M.weightedSum a.val = M.weightedSum (extendAt r s f.val) ∨
        (M.weight r ≠ 0 ∧ M.weightedSum a.val =
          M.weightedSum (extendAt r s f.val) - 2 * spin s)) := by
  classical
  let N := M.deleteVertex r (fun _ => s)
  choose repair keep delta using M.repair_extension r s
  refine ⟨repair f, repair g, ?_, keep f, keep g, delta f⟩
  let L := if M.weight r = 0 then 4 else 2
  have step : N.spectralStep L := by
    by_cases zero : M.weight r = 0
    · simpa [L, zero] using N.forest_step_four forest
    · simpa [L, zero] using N.forest_step_two forest (small zero)
  apply Relation.ReflTransGen.lift (r := fun x y : Good N =>
    (N.weightedSum y.val - N.weightedSum x.val).natAbs ≤ L) repair _ f g (step f g)
  intro x y near
  change (M.weightedSum (repair y).val - M.weightedSum (repair x).val).natAbs ≤ 4
  change (N.weightedSum y.val - N.weightedSum x.val).natAbs ≤ L at near
  have dx := delta x
  have dy := delta y
  rw [M.extendAt_sum r s (fun _ => s)] at dx dy
  change _ = _ + N.weightedSum x.val ∨ _ ∧ _ = _ + N.weightedSum x.val - _ at dx
  change _ = _ + N.weightedSum y.val ∨ _ ∧ _ = _ + N.weightedSum y.val - _ at dy
  by_cases zero : M.weight r = 0
  · simp [zero] at dx dy
    simpa [dx, dy, L, zero] using near
  · apply corrected_step s (M.weight r * spin s) (N.weightedSum x.val) (N.weightedSum y.val)
    · simpa [L, zero] using near
    · simpa [zero] using dx
    · simpa [zero] using dy


omit [Fintype V] in
private theorem extend_restrict (h : V → Bool) :
    extendAt r (h r) (fun v => h v.val) = h := by
  classical
  funext v
  by_cases e : v = r <;> simp [extendAt, e]

open Classical in
private noncomputable def restrictGood (h : Good M) : Good (M.deleteVertex r (fun _ => h.val r)) :=
  ⟨fun w => h.val w.val, fun v => (M.deleteVertex_degree r h.val v).le.trans (h.property _)⟩

private theorem sign_change_bound (s : Bool) (w source target old new : ℤ)
    (weights : w = 0 ∨ w = 1) (before : source = w * spin (!s) + old)
    (delta : new - old = 0 ∨ new - old = -2 * spin s ∨ new - old = -4 * spin s)
    (adjust : target = w * spin s + new ∨
      (w ≠ 0 ∧ target = w * spin s + new - 2 * spin s)) : (target - source).natAbs ≤ 4 := by
  rcases weights with rfl | rfl <;> cases s <;> simp [spin] at * <;> omega

open Classical in
/-- Opening at a root with two neighbors permits both root signs. -/
theorem open_cycle_step (u v : Away r)
    (cover : ∀ w : Away r, M.graph.Adj w.val r → w = u ∨ w = v)
    (weight : M.weight r = 0 ∨ M.weight r = 1)
    (forest : (M.graph.induce {w | w ≠ r}).IsAcyclic)
    (small : M.weight r ≠ 0 → ∀ w : Away r,
      M.marked w.val + (neighbors (M.graph.induce {z | z ≠ r}) w).card ≤ 2) :
    M.spectralStep 4 := by
  classical
  intro f g
  let s := g.val r
  let goal := M.restrictGood r g
  have goalEq : extendAt r s goal.val = g.val := extend_restrict r g.val
  have goalOK : ∀ w, M.monoDegree (extendAt r s goal.val) w ≤ 1 := by
    rw [goalEq]
    exact g.property
  by_cases sameSign : f.val r = s
  · let src : Good (M.deleteVertex r (fun _ => s)) :=
      ⟨fun w => f.val w.val, by rw [← sameSign]; exact (M.restrictGood r f).property⟩
    have srcEq : extendAt r s src.val = f.val := by
      change extendAt r s (fun w => f.val w.val) = f.val
      rw [← sameSign, extend_restrict]
    obtain ⟨a, b, walk, ha, hb, _⟩ := M.fixed_sign_walk r s forest small src goal
    have srcOK : ∀ w, M.monoDegree (extendAt r s src.val) w ≤ 1 := by
      rw [srcEq]
      exact f.property
    have ea : a = f := Subtype.ext ((ha srcOK).trans srcEq)
    have eb : b = g := Subtype.ext ((hb goalOK).trans goalEq)
    simpa only [ea, eb] using walk
  · have old : f.val r = !s := by cases e : f.val r <;> cases es : s <;> simp_all
    let src : Good (M.deleteVertex r (fun _ => !s)) :=
      ⟨fun w => f.val w.val, by rw [← old]; exact (M.restrictGood r f).property⟩
    have srcEq : extendAt r (!s) src.val = f.val := by
      change extendAt r (!s) (fun w => f.val w.val) = f.val
      rw [← old, extend_restrict]
    obtain ⟨tmp, delta⟩ := M.change_two_inputs r u v cover s src
    obtain ⟨a, b, walk, _, hb, adjust⟩ := M.fixed_sign_walk r s forest small tmp goal
    have eb : b = g := Subtype.ext ((hb goalOK).trans goalEq)
    rw [eb] at walk
    apply walk.head
    change (M.weightedSum a.val - M.weightedSum f.val).natAbs ≤ 4
    have before := M.extendAt_sum r (!s) (fun _ => !s) src.val
    rw [srcEq] at before
    rw [M.extendAt_sum r s (fun _ => s)] at adjust
    dsimp only at delta
    exact sign_change_bound s (M.weight r) _ _ _ _ weight before delta adjust

end QuasiBisection.BoundaryModel
