module

public import QuasiBisection.OddCactus
public import QuasiBisection.ResidualBoundary
public import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Algebra.BigOperators.Group.Finset.Lemmas

/-! Boundary estimates and parity for the complement of an even cycle packing. -/

@[expose] public section

namespace QuasiBisection

variable {V : Type*} [Fintype V] {G : SimpleGraph V}

theorem neighbor_card (x : V) : (G.neighborSet x).ncard = (neighbors G x).card := by
  classical
  have eq : (↑(neighbors G x) : Set V) = G.neighborSet x := by ext; simp [neighbors]
  rw [← eq, Set.ncard_coe_finset]

open Classical in
/-- The two cycle neighbors use two of the three distinct incidences. -/
theorem neighbors_off_cycle {x y : V} (p : G.Walk y y) (hp : p.IsCycle)
    (hx : x ∈ p.support) (subcubic : Subcubic G) :
    (G.neighborSet x \ p.toSubgraph.neighborSet x).Subsingleton := by
  apply Set.ncard_le_one_iff_subsingleton.mp
  rw [Set.ncard_sdiff (p.toSubgraph.neighborSet_subset x), neighbor_card,
    hp.ncard_neighborSet_toSubgraph_eq_two hx]
  have := subcubic x
  omega

open Classical in
theorem packing_change_exterior {F : Finset (Finset V)} (pack : EvenPacking G F)
    (subcubic : Subcubic G) {x : V} (hx : x ∉ leftover F) (a b : V → Bool)
    (unchanged : ∀ z, z ≠ x → a z = b z)
    (f : BoundaryModel.Good (residueModel G (leftover F) subcubic a)) :
    ∃ g : BoundaryModel.Good (residueModel G (leftover F) subcubic b),
      imbalance g.val = imbalance f.val ∨ imbalance g.val = imbalance f.val - 2 * spin (b x) := by
  classical
  change ¬ ∀ S ∈ F, x ∉ S at hx
  push Not at hx
  obtain ⟨S, hS, hx⟩ := hx
  obtain ⟨y, p, hp, _, rfl⟩ := pack.1 S hS
  apply change_exterior _ _ subcubic a b x unchanged _ f
  intro v w hv hw
  have mem (u : leftover F) (edge : G.Adj u.val x) :
      u.val ∈ G.neighborSet x \ p.toSubgraph.neighborSet x := by
    refine ⟨edge.symm, fun h => u.property _ hS ?_⟩
    exact List.mem_toFinset.mpr (p.mem_verts_toSubgraph.mp (p.toSubgraph.edge_vert h.symm))
  exact Subtype.ext
    (neighbors_off_cycle p hp (List.mem_toFinset.mp hx) subcubic (mem v hv) (mem w hw))

theorem cubic_even_order (cubic : Cubic G) : Even (Fintype.card V) := by
  classical
  have deg (v : V) : G.degree v = 3 := by
    rw [← cubic v, ← neighbor_card, Set.ncard_eq_toFinset_card']
    rfl
  simpa [deg, show Odd 3 from ⟨1, rfl⟩] using G.even_card_odd_degree_vertices

omit [Fintype V] in
open Classical in
theorem even_cycle_support_card {S : Finset V} (h : EvenCycleSupport G S) : Even S.card := by
  obtain ⟨y, p, hp, even, rfl⟩ := h
  have eq : p.support.toFinset = p.support.tail.toFinset := by
    ext x
    simp only [List.mem_toFinset]
    rw [p.mem_support_iff]
    exact or_iff_right_of_imp (fun eq => eq ▸ p.end_mem_tail_support hp.not_nil)
  rw [eq, List.toFinset_card_of_nodup hp.support_nodup, List.length_tail, p.length_support]
  simpa using even

open Classical in
theorem packing_even_leftover_of_even {F : Finset (Finset V)} (pack : EvenPacking G F)
    (even : Even (Fintype.card V)) :
    Even (Fintype.card (leftover F)) := by
  classical
  let U := F.biUnion id
  have eq : leftover F = {v | v ∉ U} := by
    ext v
    simp [leftover, U]
  rw [eq]
  convert_to Even (Fintype.card {v // v ∉ U}) using 2
  rw [Fintype.card_subtype_compl (· ∈ U), Fintype.card_coe]
  obtain ⟨n, hn⟩ := even
  have size : Even U.card := by
    rw [show U.card = ∑ S ∈ F, S.card from Finset.card_biUnion (t := id) pack.2]
    exact Finset.even_sum _ (fun S hS => even_cycle_support_card (pack.1 S hS))
  obtain ⟨m, hm⟩ := size
  exact ⟨n - m, by omega⟩

open Classical in
theorem packing_even_leftover {F : Finset (Finset V)} (pack : EvenPacking G F) (cubic : Cubic G) :
    Even (Fintype.card (leftover F)) :=
  packing_even_leftover_of_even pack (cubic_even_order cubic)

/-- Each spin is one modulo two, including on an empty residue. -/
theorem imbalance_even (h : V → Bool) (order : Even (Fintype.card V)) : Even (imbalance h) := by
  classical
  have each (v : V) : spin (h v) = 1 - 2 * (if h v then 0 else 1) := by
    cases h v <;> rfl
  simp only [imbalance, each, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    nsmul_eq_mul, mul_one, ← Finset.mul_sum]
  obtain ⟨n, hn⟩ := order
  exact ⟨(n : ℤ) - ∑ v, (if h v then 0 else 1), by omega⟩

end QuasiBisection
