module

public import QuasiBisection.SingleDefect

/-! Discharging the two monochromatic cycle edges at the ends of an inverted segment. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

variable {V : Type*} [Fintype V] (M : BoundaryModel V)

open Classical in
/-- The one unit of extra monochromatic degree permitted at either endpoint. -/
noncomputable def endpoint (a b v : V) : ℕ := if v = a ∨ v = b then 1 else 0

private theorem clear_edge (unit : ∀ v, M.weight v = 1) (h : V → Bool)
    (a b : V) (adj : M.graph.Adj a b) (s : Bool) (budget : V → ℕ)
    (positive : ∀ v, 1 ≤ budget v)
    (cap : ∀ v, M.monoDegree h v ≤ budget v + endpoint a b v)
    (color : ∀ v, v = a ∨ v = b → 2 ≤ M.monoDegree h v → h v = s) :
    ∃ g, (M.weightedSum g = M.weightedSum h ∨
        M.weightedSum g = M.weightedSum h - 2 * spin s) ∧
      (∀ v, M.monoDegree g v ≤ budget v) ∧
      ∀ v, 2 ≤ M.monoDegree g v → g v = h v ∧ 2 ≤ M.monoDegree h v := by
  classical
  by_cases done : ∀ v, M.monoDegree h v ≤ budget v
  · exact ⟨h, Or.inl rfl, done, fun _ hv => ⟨rfl, hv⟩⟩
  obtain ⟨r, hr⟩ := Classical.not_forall.mp done
  have marked (v : V) (excess : ¬ M.monoDegree h v ≤ budget v) : v = a ∨ v = b := by
    by_contra other
    have := cap v
    simp only [endpoint, other, ite_false, Nat.add_zero] at this
    exact excess this
  have bad : 2 ≤ M.monoDegree h r := by have := positive r; omega
  have er := marked r hr
  have sr := color r er bad
  obtain ⟨g, diff, rest⟩ := M.repair_among_defects unit h r bad
  refine ⟨g, by simpa only [sr] using diff, fun v => ?_, fun v hv => ?_⟩
  · by_contra! excess
    have dv : 2 ≤ M.monoDegree g v := by have := positive v; omega
    obtain ⟨ne, _, drop⟩ := rest v dv
    have old : ¬ M.monoDegree h v ≤ budget v := by omega
    have ev := marked v old
    have edge : M.graph.Adj r v := by
      rcases er with rfl | rfl <;> rcases ev with rfl | rfl <;> solve_by_elim [adj.symm]
    have sv := color v ev (by omega)
    have hit : M.edgeHit h r v = 1 := by simp [edgeHit, edge, same, sr, sv]
    have := cap v
    simp only [endpoint, ev, ↓reduceIte] at this
    omega
  · obtain ⟨_, eq, drop⟩ := rest v hv
    exact ⟨eq, by omega⟩

/-- Each marked edge costs at most one repair chain of its own starting
color. The endpoints may overlap, including at a degree-three defect. -/
theorem repair_two_edges (unit : ∀ v, M.weight v = 1) (h : V → Bool)
    (a b c d : V) (first : M.graph.Adj a b) (second : M.graph.Adj c d)
    (s t : Bool) (ha : h a = s) (hb : h b = s) (hc : h c = t) (hd : h d = t)
    (cap : ∀ v, M.monoDegree h v ≤ 1 + endpoint c d v + endpoint a b v)
    (sum : M.weightedSum h = spin s + spin t) :
    ∃ g, (∀ v, M.monoDegree g v ≤ 1) ∧ (M.weightedSum g).natAbs ≤ 2 := by
  obtain ⟨k, dk, bound, keep⟩ := M.clear_edge unit h a b first s
    (fun v => 1 + endpoint c d v) (fun _ => Nat.le_add_right ..) cap
    (fun v hv _ => hv.elim (fun e => e ▸ ha) (fun e => e ▸ hb))
  obtain ⟨g, dg, valid, _⟩ := M.clear_edge unit k c d second t (fun _ => 1)
    (fun _ => le_rfl) bound (fun v hv bad =>
      (keep v bad).1.trans (hv.elim (fun e => e ▸ hc) (fun e => e ▸ hd)))
  exact ⟨g, valid, by cases s <;> cases t <;> simp [spin] at sum dk dg <;> omega⟩

end QuasiBisection.BoundaryModel
