module

public import QuasiBisection.CycleSpectrum
public import Mathlib.Combinatorics.SimpleGraph.Connectivity.Subgraph

/-! Structural hypotheses for opening any finite connected two-regular graph. -/

@[expose] public section

namespace QuasiBisection

open SimpleGraph

variable {V : Type*} [Fintype V]

/-- Within a connected graph of maximum degree two, a cycle uses every vertex. -/
theorem cycle_spans_of_degree_le_two (G : SimpleGraph V) (conn : G.Connected)
    (degree : ∀ v, (neighbors G v).card ≤ 2) {x : V} {p : G.Walk x x} (cyc : p.IsCycle) :
    ∀ v, v ∈ p.support := by
  classical
  have closed {a b : V} (ha : a ∈ p.support) (edge : G.Adj a b) : b ∈ p.support := by
    have eq : p.toSubgraph.neighborSet a = G.neighborSet a := by
      apply Set.eq_of_subset_of_ncard_le (p.toSubgraph.neighborSet_subset a)
      rw [cyc.ncard_neighborSet_toSubgraph_eq_two ha]
      have sets : (↑(neighbors G a) : Set V) = G.neighborSet a := by
        ext v
        simp [neighbors]
      rw [← sets, Set.ncard_coe_finset]
      exact degree a
    have mem : b ∈ p.toSubgraph.neighborSet a := eq.symm ▸ edge
    exact p.mem_verts_toSubgraph.mp (p.toSubgraph.edge_vert (p.toSubgraph.adj_symm mem))
  intro v
  have path := (SimpleGraph.reachable_iff_reflTransGen (G := G) x v).mp (conn.preconnected x v)
  induction path with
  | refl => exact p.start_mem_support
  | tail _ adj ih => exact closed ih adj

theorem acyclic_delete_of_degree_le_two (G : SimpleGraph V) (conn : G.Connected)
    (degree : ∀ v, (neighbors G v).card ≤ 2) (r : V) :
    (G.induce {v | v ≠ r}).IsAcyclic := by
  intro x p cyc
  let emb := SimpleGraph.Embedding.induce (G := G) {v | v ≠ r}
  have mapped := cyc.map (f := emb.toHom) emb.injective
  have mem := cycle_spans_of_degree_le_two G conn degree mapped r
  rw [Walk.support_map, List.mem_map] at mem
  obtain ⟨u, _, eq⟩ := mem
  exact u.property eq

namespace BoundaryModel

/-- The spectrum of a finite simple cycle has gaps at most four for all
legal fixed slots, opposite slots and marks. -/
theorem cycle_step_four (M : BoundaryModel V) (conn : M.graph.Connected)
    (degree : ∀ v, (neighbors M.graph v).card = 2) : M.spectralStep 4 := by
  classical
  have root : ∃ r : V, M.weight r ≠ 0 → ∀ v, M.weight v ≠ 0 := by
    by_cases zero : ∃ r, M.weight r = 0
    · obtain ⟨r, hr⟩ := zero
      exact ⟨r, fun ne => (ne hr).elim⟩
    · exact ⟨conn.nonempty.some, fun _ v hv => zero ⟨v, hv⟩⟩
  obtain ⟨r, select⟩ := root
  obtain ⟨u, v, _, pair⟩ := Finset.card_eq_two.mp (degree r)
  have incident (w : V) : M.graph.Adj r w ↔ w = u ∨ w = v := by
    have eq : w ∈ neighbors M.graph r ↔ w = u ∨ w = v := by simp [pair]
    simpa [neighbors] using eq
  have marks (w : V) : M.marked w ≤ 1 := by
    have := M.marked_le w
    have := M.budget w
    have := degree w
    omega
  apply M.open_cycle_step r ⟨u, ((incident u).mpr (Or.inl rfl)).ne.symm⟩
    ⟨v, ((incident v).mpr (Or.inr rfl)).ne.symm⟩
  · intro w edge
    exact ((incident _).mp edge.symm).imp (fun e => Subtype.ext e) (fun e => Subtype.ext e)
  · have := marks r
    unfold weight
    omega
  · exact acyclic_delete_of_degree_le_two M.graph conn (fun v => (degree v).le) r
  · intro nonzero w
    have ok := select nonzero w.val
    unfold weight at ok
    have := marks w.val
    have := degree w.val
    have card := M.sum_neighbors_away r w (fun _ => 1)
    simp only [Finset.sum_const, smul_eq_mul, mul_one] at card
    omega

end BoundaryModel
end QuasiBisection
