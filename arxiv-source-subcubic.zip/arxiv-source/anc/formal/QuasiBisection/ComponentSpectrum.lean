module

public import QuasiBisection.CactusSpectrum

/-! Lifting component walks to a possibly disconnected boundary model. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

open Bridge

variable {V : Type*} [Fintype V] (M : BoundaryModel V) (C : M.graph.ConnectedComponent)

open Classical in
private theorem component_neighbors (v : C.supp) (f : V → ℕ) :
    ∑ u ∈ neighbors M.graph v.val, f u =
      ∑ u ∈ neighbors C.toSimpleGraph v, f u.val := by
  classical
  have split := Fintype.sum_subtype_add_sum_subtype (· ∈ C.supp)
    (fun u => if M.graph.Adj v.val u then f u else 0)
  have outside (u : {x // x ∉ C.supp}) : ¬ M.graph.Adj v.val u.val :=
    fun adj => u.property (C.mem_supp_of_adj_mem_supp v.property adj)
  change _ = ∑ u ∈ neighbors (M.graph.induce C.supp) v, f u.val
  simpa only [neighbors, Finset.sum_filter, SimpleGraph.induce_adj, outside, ite_false,
    Finset.sum_const_zero,
    Nat.add_zero] using split.symm

open Classical in
noncomputable def componentModel : BoundaryModel C.supp where
  graph := C.toSimpleGraph
  fixed v := M.fixed v.val
  marked v := M.marked v.val
  opposite v := M.opposite v.val
  marked_le v := M.marked_le v.val
  budget v := by
    have cnt := M.component_neighbors C v (fun _ => 1)
    simp only [Finset.sum_const, smul_eq_mul, mul_one] at cnt
    rw [← cnt]
    exact M.budget v.val

open Classical in
theorem component_degree (h : V → Bool) (v : C.supp) :
    (M.componentModel C).monoDegree (fun u => h u.val) v = M.monoDegree h v.val := by
  unfold monoDegree inside
  rw [M.component_neighbors C v]
  rfl

open Classical in
private noncomputable def restrictGood (f : Good M) : Good (M.componentModel C) :=
  ⟨fun v => f.val v.val, fun v => (M.component_degree C f.val v).le.trans (f.property _)⟩

open Classical in
/-- Change just one component. On every other component the old coloring
still witnesses admissibility. -/
private noncomputable def replaceComponent (f : Good M) (g : Good (M.componentModel C)) :
    Good M := by
  classical
  let h (v : V) := if hv : v ∈ C.supp then g.val ⟨v, hv⟩ else f.val v
  refine ⟨h, fun v => ?_⟩
  let D := M.graph.connectedComponentMk v
  let u : D.supp := ⟨v, rfl⟩
  by_cases hv : v ∈ C.supp
  · rw [← M.component_degree C h ⟨v, hv⟩]
    have eq (w : C.supp) : h w.val = g.val w := dite_eq_left w.property
    simpa only [eq] using g.property ⟨v, hv⟩
  · have eq (w : D.supp) : h w.val = f.val w.val := by
      apply dite_eq_right
      exact fun hw => hv ((C.mem_supp_iff v).mpr (w.property.symm.trans hw))
    change M.monoDegree h u.val ≤ 1
    rw [← M.component_degree D h u]
    simp only [eq, M.component_degree]
    exact f.property v

open Classical in
private theorem replace_sum (f : Good M) (g : Good (M.componentModel C)) :
    M.weightedSum (M.replaceComponent C f g).val =
      (M.componentModel C).weightedSum g.val +
        ∑ w : {x // x ∉ C.supp}, M.weight w.val * spin (f.val w.val) := by
  classical
  unfold weightedSum
  rw [← Fintype.sum_subtype_add_sum_subtype (· ∈ C.supp)]
  simp only [replaceComponent, Subtype.property, ↓reduceDIte, componentModel, weight,
    dite_eq_right (Subtype.property (_ : {x // x ∉ C.supp}))]

/-- At fixed boundary, process one component at a time. This includes the
empty model and any number of tree or cactus components. -/
theorem cactus_forest_step_four (cactus : CactusCycles M.graph) : M.spectralStep 4 := by
  classical
  let _ := Fintype.ofFinite M.graph.ConnectedComponent
  intro f g
  let weight := fun h : Good M => M.weightedSum h.val
  have visit (s : Finset M.graph.ConnectedComponent) :
      ∃ h : Good M, Walk 4 weight f h ∧ ∀ v,
        h.val v = if M.graph.connectedComponentMk v ∈ s then g.val v else f.val v := by
    induction s using Finset.induction_on with
    | empty => exact ⟨f, .refl, by simp⟩
    | @insert c s fresh ih =>
      obtain ⟨h, path, colors⟩ := ih
      let N := M.componentModel c
      let lift := M.replaceComponent c h
      let a := M.restrictGood c h
      let b := M.restrictGood c g
      have localWalk := N.cactus_step_four c.connected_toSimpleGraph (cactus.induce c.supp) a b
      have lifted : Walk 4 weight (lift a) (lift b) := by
        apply Relation.ReflTransGen.lift (r := fun x y : Good N =>
          (N.weightedSum y.val - N.weightedSum x.val).natAbs ≤ 4) lift _ a b localWalk
        intro x y near
        change (M.weightedSum (M.replaceComponent c h y).val -
          M.weightedSum (M.replaceComponent c h x).val).natAbs ≤ 4
        simpa only [M.replace_sum, add_sub_add_right_eq_sub] using near
      have start : lift a = h := Subtype.ext (by
        funext v
        simp [lift, a, replaceComponent, restrictGood])
      rw [start] at lifted
      refine ⟨lift b, path.trans lifted, fun v => ?_⟩
      by_cases hv : v ∈ c.supp
      · simp [lift, b, replaceComponent, restrictGood, (c.mem_supp_iff v).mp hv]
      · simp [lift, b, replaceComponent, colors, (c.mem_supp_iff v).not.mp hv]
  obtain ⟨h, path, colors⟩ := visit Finset.univ
  have eq : h = g := Subtype.ext (funext (fun v => by simpa using colors v))
  exact eq ▸ path

end QuasiBisection.BoundaryModel
