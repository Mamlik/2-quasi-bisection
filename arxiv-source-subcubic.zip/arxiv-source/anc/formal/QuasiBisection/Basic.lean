module

public import Mathlib.Combinatorics.SimpleGraph.Basic
public import Mathlib.Algebra.BigOperators.Ring.Finset

/-! The statement of the cubic 2-quasi-bisection problem. -/

@[expose] public section

namespace QuasiBisection

def spin (b : Bool) : ℤ := if b then 1 else -1

variable {V : Type*} [Fintype V]

noncomputable def neighbors (G : SimpleGraph V) (v : V) : Finset V := by
  classical
  exact Finset.univ.filter (G.Adj v)

def Cubic (G : SimpleGraph V) : Prop := ∀ v, (neighbors G v).card = 3

/-- Every vertex has at most three neighbors. -/
def Subcubic (G : SimpleGraph V) : Prop := ∀ v, (neighbors G v).card ≤ 3

theorem Cubic.subcubic {G : SimpleGraph V} (h : Cubic G) : Subcubic G :=
  fun v => (h v).le

def Admissible (G : SimpleGraph V) (h : V → Bool) : Prop :=
  ∀ v, ((neighbors G v).filter (fun u => h u = h v)).card ≤ 1

def imbalance (h : V → Bool) : ℤ := ∑ v, spin (h v)

/-- Conjecture 10 for finite simple cubic graphs, proved in `MainTheorem`. -/
def CubicQuasiBisectionStatement (V : Type*) [Fintype V] : Prop :=
  ∀ G : SimpleGraph V, Cubic G → ∃ h : V → Bool, Admissible G h ∧ (imbalance h).natAbs ≤ 2

end QuasiBisection
