module

public import QuasiBisection.Basic

/-! Local accounting for a graph with fixed and always-opposite boundary slots. -/

@[expose] public section

namespace QuasiBisection

variable {V : Type*} [Fintype V]

/-- Fixed slots are counted by colour. Of the opposite slots only marked ones
reduce the vertex weight. The slot budget counts internal neighbours once. -/
structure BoundaryModel (V : Type*) [Fintype V] where
  graph : SimpleGraph V
  fixed : V → Bool → ℕ
  opposite : V → ℕ
  marked : V → ℕ
  marked_le : ∀ v, marked v ≤ opposite v
  budget : ∀ v, (neighbors graph v).card + fixed v true + fixed v false + opposite v = 3

namespace BoundaryModel

def weight (M : BoundaryModel V) (v : V) : ℤ := 1 - (M.marked v : ℤ)

noncomputable def flip (h : V → Bool) (r : V) : V → Bool := fun v => by
  classical
  exact if v = r then !(h r) else h v

def same (s t : Bool) : ℕ := if s = t then 1 else 0

noncomputable def inside (M : BoundaryModel V) (h : V → Bool) (v : V) : ℕ :=
  ∑ u ∈ neighbors M.graph v, same (h v) (h u)

noncomputable def monoDegree (M : BoundaryModel V) (h : V → Bool) (v : V) : ℕ :=
  M.inside h v + M.fixed v (h v)

private theorem same_complement (s t : Bool) : same (!s) t + same s t = 1 := by
  cases s <;> cases t <;> decide

/-- Accounting at the flipped vertex, including fixed and opposite slots. -/
theorem flip_root (M : BoundaryModel V) (h : V → Bool) (r : V) :
    M.monoDegree (flip h r) r + M.monoDegree h r + M.opposite r = 3 := by
  classical
  have insideSum : M.inside (flip h r) r + M.inside h r = (neighbors M.graph r).card := by
    unfold inside
    rw [← Finset.sum_add_distrib]
    calc
      _ = ∑ _u ∈ neighbors M.graph r, (1 : ℕ) := by
        apply Finset.sum_congr rfl
        intro u hu
        have adj : M.graph.Adj r u := (Finset.mem_filter.mp hu).2
        have hu' : u ≠ r := fun e => adj.ne e.symm
        simp only [flip, ite_eq_right hu', ↓reduceIte]
        exact same_complement _ _
      _ = _ := by simp
  have fixedSum : M.fixed r ((flip h r) r) + M.fixed r (h r) =
      M.fixed r true + M.fixed r false := by
    simp only [flip, ↓reduceIte]
    cases h r <;> simp [Nat.add_comm]
  unfold monoDegree
  have := M.budget r
  omega

/-- A propagating defect leaves one match at the old root, forcing weight one.
At a stopping defect the weight may instead be zero. -/
theorem defect_weights (M : BoundaryModel V) (h : V → Bool) (r : V)
    (bad : 2 ≤ M.monoDegree h r) :
    (M.weight r = 0 ∨ M.weight r = 1) ∧
      (0 < M.monoDegree (flip h r) r → M.weight r = 1) := by
  have := M.flip_root h r
  have := M.marked_le r
  unfold weight
  omega

end BoundaryModel
end QuasiBisection
