module

public import QuasiBisection.InversionRepair

/-! The even-order subcubic 2-quasi-bisection theorem and its cubic specialization. During inversion
each residual step has size at most two. Once the exterior is fixed, the cactus spectrum joins
the final residual coloring to the complement of the initial one. -/

@[expose] public section

namespace QuasiBisection

open CycleOrder BoundaryModel

variable {V : Type*} [Fintype V] {G : SimpleGraph V} {F : Finset (Finset V)}

namespace EvenPacking

variable (P : EvenPacking G F) (subcubic : Subcubic G)

open Classical in
private theorem advance_vertex (k : F → ℕ) (T : F) (j : Fin (P.order T).size)
    (r : P.ResidueGood subcubic (Function.update k T j.val)) :
    ∃ g : P.ResidueGood subcubic (Function.update k T (j.val + 1)),
      (imbalance g.val - imbalance r.val).natAbs ≤ 2 := by
  classical
  let a := P.coloring (Function.update k T j.val) (fun _ => false)
  let b := P.coloring (Function.update k T (j.val + 1)) (fun _ => false)
  let x := P.atPos ⟨T,j⟩
  have agree (v : V) (ne : v ≠ x) : a v = b v := by
    obtain ⟨w | ⟨U, i⟩, rfl⟩ := P.coordinates.surjective v
    · simp [a, b]
    · by_cases eq : U = T
      · subst U
        have diff : i.val ≠ j.val := fun h => ne (congrArg (fun z => P.atPos ⟨T,z⟩) (Fin.ext h))
        simp only [a, b, coordinates_right, coloring_right, Function.update_self]
        unfold prefixColor
        split_ifs <;> first | rfl | omega
      · simp [a, b, Function.update_of_ne eq]
  obtain ⟨g, delta⟩ := packing_change_exterior P subcubic (P.atPos_not_leftover ⟨T,j⟩) a b agree r
  refine ⟨g, ?_⟩
  cases e : b (P.atPos ⟨T,j⟩) <;> simp only [e, spin] at delta <;> omega

open Classical in
private theorem zero_during_cycle (k : F → ℕ) (T : F) (bound : k T ≤ (P.order T).size)
    (others : ∀ U, U ≠ T → P.Settled k U) (r : P.ResidueGood subcubic k)
    (zero : imbalance r.val = 0) : HasQuasiBisection G := by
  by_cases done : P.Settled k T
  · apply P.finish_settled subcubic k _ r (by simp [zero])
    intro U
    by_cases eq : U = T
    · exact eq ▸ done
    · exact others U eq
  · have incomplete : k T ≠ 0 ∧ k T ≠ (P.order T).size := not_or.mp done
    exact P.finish_partial subcubic k T others (by omega) (by omega) r zero

open Classical in
/-- Traverse a whole cycle. In the absence of a solution the nonzero even
sum on the residue must keep its sign at every one-vertex transition. -/
private theorem advance_cycle (evenOrder : Even (Fintype.card V))
    (noSolution : ¬ HasQuasiBisection G) (k : F → ℕ) (T : F)
    (others : ∀ U, U ≠ T → P.Settled k U) (r : P.ResidueGood subcubic (Function.update k T 0)) :
    ∃ g : P.ResidueGood subcubic (Function.update k T (P.order T).size),
      (0 < imbalance r.val ↔ 0 < imbalance g.val) := by
  classical
  have nonzero (j : ℕ) (bound : j ≤ (P.order T).size)
      (g : P.ResidueGood subcubic (Function.update k T j)) : imbalance g.val ≠ 0 := by
    intro zero
    apply noSolution (P.zero_during_cycle subcubic _ T _ _ g zero)
    · simpa only [Function.update_self] using bound
    · intro U ne
      simpa only [Settled, Function.update_of_ne ne] using others U ne
  have even (h : leftover F → Bool) := imbalance_even h (packing_even_leftover_of_even P evenOrder)
  have reach (j : ℕ) (le : j ≤ (P.order T).size) :
      ∃ g : P.ResidueGood subcubic (Function.update k T j),
        (0 < imbalance r.val ↔ 0 < imbalance g.val) := by
    induction j with
    | zero => exact ⟨r, Iff.rfl⟩
    | succ j ih =>
      obtain ⟨g, sign⟩ := ih (by omega)
      obtain ⟨h, step⟩ := P.advance_vertex subcubic k T ⟨j, by omega⟩ g
      have nz₁ := nonzero j (by omega) g
      have nz₂ := nonzero (j + 1) le h
      obtain ⟨a, ha⟩ := even g.val
      obtain ⟨b, hb⟩ := even h.val
      exact ⟨h, sign.trans (by omega)⟩
  exact reach _ le_rfl

open Classical in
private theorem invert_packing (evenOrder : Even (Fintype.card V))
    (noSolution : ¬ HasQuasiBisection G)
    (r : P.ResidueGood subcubic (fun _ => 0)) :
    ∃ g : P.ResidueGood subcubic (fun T => (P.order T).size),
      (0 < imbalance r.val ↔ 0 < imbalance g.val) := by
  classical
  let cut (A : Finset F) (T : F) := if T ∈ A then (P.order T).size else 0
  have reach (A : Finset F) : ∃ h : P.ResidueGood subcubic (cut A),
      (0 < imbalance r.val ↔ 0 < imbalance h.val) := by
    induction A using Finset.induction_on with
    | empty =>
      rw [show cut ∅ = fun _ => 0 by funext; simp [cut]]
      exact ⟨r, Iff.rfl⟩
    | @insert T A fresh ih =>
      obtain ⟨h, sign⟩ := ih
      have start : Function.update (cut A) T 0 = cut A := by
        funext U
        by_cases eq : U = T <;> simp [Function.update, cut, eq, fresh]
      have finish : Function.update (cut A) T (P.order T).size = cut (insert T A) := by
        funext U
        by_cases eq : U = T <;> simp [Function.update, cut, eq]
      have walk := P.advance_cycle subcubic evenOrder noSolution (cut A) T (fun U _ => by
        unfold Settled cut
        split <;> simp)
      rw [start, finish] at walk
      obtain ⟨g, sign'⟩ := walk h
      exact ⟨g, sign.trans sign'⟩
  have path := reach Finset.univ
  rw [show cut Finset.univ = fun T => (P.order T).size by funext; simp [cut]] at path
  exact path

open Classical in
private theorem inverted_initial (r : P.ResidueGood subcubic (fun _ => 0)) :
    ∃ g : P.ResidueGood subcubic (fun T => (P.order T).size),
      imbalance g.val = -imbalance r.val := by
  classical
  let final := fun T => (P.order T).size
  let g (v : leftover F) := !(r.val v)
  have inverted (v : V) :
      P.coloring final g v = !(P.coloring (fun _ => 0) r.val v) := by
    obtain ⟨w | ⟨T, i⟩, rfl⟩ := P.coordinates.surjective v
    · simp [g]
    · simp [final, prefixColor, i.isLt]
  have valid (w : leftover F) :
      (residueModel G (leftover F) subcubic
        (P.coloring final (fun _ => false))).monoDegree g w ≤ 1 := by
    rw [← P.coloring_degree_left, subcubicModel_degree]
    have cancel (a b : Bool) : ((!a) = !b) ↔ a = b := by cases a <;> cases b <;> decide
    simpa only [inverted, cancel] using
      (show ((neighbors G w.val).filter (fun u =>
        P.coloring (fun _ => 0) r.val u = P.coloring (fun _ => 0) r.val w.val)).card ≤ 1 by
          rw [← subcubicModel_degree subcubic]
          exact P.coloring_good_left subcubic _ r w)
  refine ⟨⟨g, valid⟩, ?_⟩
  change imbalance g = -imbalance r.val
  have flipSpin (b : Bool) : spin (!b) = -spin b := by cases b <;> rfl
  simp only [imbalance, g, flipSpin, Finset.sum_neg_distrib]

end EvenPacking

/-- Every even-order finite simple subcubic graph admits a coloring of monochromatic
degree at most one and absolute imbalance at most two. -/
theorem subcubic_quasi_bisection (G : SimpleGraph V) (subcubic : Subcubic G)
    (evenOrder : Even (Fintype.card V)) :
    ∃ h : V → Bool, Admissible G h ∧ (imbalance h).natAbs ≤ 2 := by
  classical
  obtain ⟨F, P, cactus, _⟩ := exists_even_packing_cactus G
  change EvenPacking.HasQuasiBisection G
  by_contra noSolution
  let start : F → ℕ := fun _ => 0
  let finish := fun T => (P.order T).size
  let N := residueModel G (leftover F) subcubic (P.coloring start (fun _ => false))
  obtain ⟨r, _, good⟩ := N.repair_exists (fun _ => false)
  let f : P.ResidueGood subcubic start := ⟨r, good⟩
  obtain ⟨g, sign⟩ := P.invert_packing subcubic evenOrder noSolution f
  obtain ⟨h, sum⟩ := P.inverted_initial subcubic f
  have far (x : P.ResidueGood subcubic finish) : 2 < (imbalance x.val).natAbs := by
    by_contra! small
    exact noSolution (P.finish_settled subcubic finish (fun _ => Or.inr rfl) x small)
  have walk := residue_step_four G (leftover F) subcubic (P.coloring finish (fun _ => false))
    cactus g h
  have preserves {a b : P.ResidueGood subcubic finish}
      (path : Bridge.Walk 4 (fun x : P.ResidueGood subcubic finish => imbalance x.val) a b) :
      (0 < imbalance a.val ↔ 0 < imbalance b.val) := by
    induction path with
    | refl => exact Iff.rfl
    | @tail b c _ step ih =>
      change (imbalance c.val - imbalance b.val).natAbs ≤ 4 at step
      have := far b
      have := far c
      exact ih.trans (by omega)
  have sameSign := sign.trans (preserves walk)
  have := far h
  omega

/-- The cubic case has even order by the handshaking identity. -/
theorem cubic_quasi_bisection (V : Type*) [Fintype V] : CubicQuasiBisectionStatement V :=
  fun G cubic => subcubic_quasi_bisection G cubic.subcubic (cubic_even_order cubic)

private theorem color_component_card {h : V → Bool} (good : Admissible G h) (b : Bool)
    (C : (G.induce {x | h x = b}).ConnectedComponent) : C.supp.ncard ≤ 2 := by
  classical
  let H := G.induce {x | h x = b}
  have degree (u : {x // h x = b}) : (H.neighborSet u).ncard ≤ 1 := by
    let N := (neighbors G u.val).filter (fun w => h w = h u.val)
    have bound : (H.neighborSet u).ncard ≤ (N : Set V).ncard :=
      Set.ncard_le_ncard_of_injOn Subtype.val (fun w adj => Finset.mem_filter.mpr
        ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, adj⟩, w.property.trans u.property.symm⟩)
        Subtype.val_injective.injOn
    rw [Set.ncard_coe_finset] at bound
    exact bound.trans (good u.val)
  obtain ⟨v, hv⟩ := C.nonempty_supp
  have cover : C.supp ⊆ insert v (H.neighborSet v) := by
    intro w hw
    have path := (SimpleGraph.reachable_iff_reflTransGen (G := H) v w).mp
      (C.reachable_of_mem_supp hv hw)
    clear hw
    induction path with
    | refl => exact Set.mem_insert _ _
    | @tail u w _ adj ih =>
      rcases ih with eq | near
      · exact Or.inr (eq ▸ adj)
      · exact Or.inl ((Set.ncard_le_one_iff_subsingleton.mp (degree u)) adj near.symm)
  have bound := Set.ncard_insert_le v (H.neighborSet v)
  exact (Set.ncard_le_ncard cover).trans (bound.trans (by have := degree v; omega))

/-- The same conclusion expressed directly by the sizes of the two classes
and of each connected component of either induced monochromatic graph. -/
theorem subcubic_quasi_bisection_classes {V : Type*} [Finite V] (G : SimpleGraph V)
    (deg : ∀ v, (G.neighborSet v).ncard ≤ 3) (evenOrder : Even (Nat.card V)) :
    ∃ h : V → Bool,
      |({v | h v = true}.ncard : ℤ) - ({v | h v = false}.ncard : ℤ)| ≤ 2 ∧
      ∀ b (C : (G.induce {v | h v = b}).ConnectedComponent), C.supp.ncard ≤ 2 := by
  classical
  let _ := Fintype.ofFinite V
  have subcubic : Subcubic G := by
    intro v
    rw [← neighbor_card]
    exact deg v
  obtain ⟨h, good, small⟩ := subcubic_quasi_bisection G subcubic
    (by simpa only [Nat.card_eq_fintype_card] using evenOrder)
  refine ⟨h, ?_, color_component_card good⟩
  have each (v : V) : spin (h v) =
      (if h v = true then (1 : ℤ) else 0) - (if h v = false then 1 else 0) := by
    cases h v <;> rfl
  have sum : imbalance h = ({v | h v = true}.ncard : ℤ) - ({v | h v = false}.ncard : ℤ) := by
    simp only [imbalance, each, Finset.sum_sub_distrib, Finset.sum_boole,
      Set.ncard_eq_toFinset_card']
    congr 3 <;> ext <;> simp
  rw [← sum, ← Int.natCast_natAbs]
  exact_mod_cast small

/-- Exact-degree specialization of the color-class formulation. -/
theorem cubic_quasi_bisection_classes {V : Type*} [Finite V] (G : SimpleGraph V)
    (deg : ∀ v, (G.neighborSet v).ncard = 3) :
    ∃ h : V → Bool,
      |({v | h v = true}.ncard : ℤ) - ({v | h v = false}.ncard : ℤ)| ≤ 2 ∧
      ∀ b (C : (G.induce {v | h v = b}).ConnectedComponent), C.supp.ncard ≤ 2 := by
  classical
  let _ := Fintype.ofFinite V
  apply subcubic_quasi_bisection_classes G (fun v => (deg v).le)
  rw [Nat.card_eq_fintype_card]
  apply cubic_even_order (G := G)
  intro v
  rw [← neighbor_card]
  exact deg v

end QuasiBisection
