module

public import QuasiBisection.BridgeContraction
public import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected

/-! Cutting an edge of a boundary model along a bridge. The two induced
models reserve an unmarked opposite slot at each end of the deleted edge. -/

@[expose] public section

namespace QuasiBisection

variable {V : Type*} {G : SimpleGraph V}

/-- An oriented partition with exactly one crossing edge. -/
structure BridgeCut (G : SimpleGraph V) where
  carrier : Set V
  root : carrier
  tip : V
  tip_outside : tip ∉ carrier
  crossing : ∀ (v : carrier) (w : V), w ∉ carrier →
    (G.Adj v.val w ↔ v = root ∧ w = tip)

namespace BridgeCut

/-- Choose the component of the first endpoint after deleting the bridge.
Any components unrelated to the bridge belong to the complementary side. -/
def ofIsBridge {x y : V} (edge : G.Adj x y) (bridge : G.IsBridge s(x, y)) : BridgeCut G where
  carrier := {v | (G.deleteEdges {s(x, y)}).Reachable x v}
  root := ⟨x, SimpleGraph.Reachable.rfl⟩
  tip := y
  tip_outside := SimpleGraph.isBridge_iff.mp bridge
  crossing := by
    intro v w hw
    constructor
    · intro adj
      have eq : s(v.val, w) = s(x, y) := by
        by_contra ne
        apply hw
        exact v.property.trans (SimpleGraph.deleteEdges_adj.mpr ⟨adj, by simpa using ne⟩).reachable
      rcases Sym2.eq_iff.mp eq with h | h
      · exact ⟨Subtype.ext h.1, h.2⟩
      · exact False.elim (hw (h.2 ▸ SimpleGraph.Reachable.rfl))
    · rintro ⟨rfl, rfl⟩
      exact edge

variable (c : BridgeCut G)

/-- View the same crossing edge from its other end. -/
def reverse : BridgeCut G where
  carrier := c.carrierᶜ
  root := ⟨c.tip, c.tip_outside⟩
  tip := c.root
  tip_outside := fun h => h c.root.property
  crossing := by
    intro v w hw
    have hw' : w ∈ c.carrier := Classical.byContradiction hw
    rw [G.adj_comm, c.crossing ⟨w, hw'⟩ v.val v.property]
    constructor
    · rintro ⟨h, e⟩
      exact ⟨Subtype.ext e, congrArg Subtype.val h⟩
    · rintro ⟨h, e⟩
      exact ⟨Subtype.ext e, congrArg Subtype.val h⟩

/-- Either induced side of a bridge in a connected graph is connected.
A walk returning to this side from its complement re-enters at the root. -/
theorem connected_induce (conn : G.Connected) : (G.induce c.carrier).Connected := by
  apply (SimpleGraph.connected_iff_exists_forall_reachable _).mpr
  refine ⟨c.root, fun v => ?_⟩
  have restrictWalk (w : V) (walk : Relation.ReflTransGen G.Adj c.root.val w) :
      ∀ hw : w ∈ c.carrier, (G.induce c.carrier).Reachable c.root ⟨w, hw⟩ := by
    induction walk with
    | refl => exact fun _ => .rfl
    | @tail u z _ adj ih =>
      intro hz
      by_cases hu : u ∈ c.carrier
      · exact (ih hu).trans (SimpleGraph.induce_adj.mpr adj).reachable
      · have eq := ((c.crossing ⟨z, hz⟩ u hu).mp adj.symm).1
        rw [eq]
  exact restrictWalk v.val ((SimpleGraph.reachable_iff_reflTransGen ..).mp (conn _ _)) v.property

variable [Fintype V]

open Classical in
/-- The original neighbor sum is the internal sum plus the contribution
of the other endpoint, counted only at the root. -/
theorem sum_neighbors (v : c.carrier) (f : V → ℕ) :
    ∑ w ∈ neighbors G v.val, f w =
      (∑ w ∈ neighbors (G.induce c.carrier) v, f w.val) +
        if v = c.root then f c.tip else 0 := by
  classical
  simp only [neighbors, Finset.sum_filter, SimpleGraph.induce_adj]
  rw [← Fintype.sum_subtype_add_sum_subtype (· ∈ c.carrier)
    (fun w => if G.Adj v.val w then f w else 0)]
  congr 1
  let tip : {w // w ∉ c.carrier} := ⟨c.tip, c.tip_outside⟩
  have test (w : {w // w ∉ c.carrier}) :
      G.Adj v.val w.val ↔ v = c.root ∧ w = tip := by
    rw [c.crossing v w.val w.property]
    simp [tip, Subtype.ext_iff]
  simp only [test]
  by_cases h : v = c.root <;> simp [h, tip]

open Classical in
/-- Restrict the graph and its slots to one side; the crossing incidence
becomes an additional opposite slot with no new mark. -/
noncomputable def model (M : BoundaryModel V) (c : BridgeCut M.graph) :
    BoundaryModel c.carrier where
  graph := M.graph.induce c.carrier
  fixed v := M.fixed v.val
  opposite v := M.opposite v.val + if v = c.root then 1 else 0
  marked v := M.marked v.val
  marked_le v := (M.marked_le v.val).trans (Nat.le_add_right _ _)
  budget v := by
    have counts := c.sum_neighbors v (fun _ => 1)
    simp only [Finset.sum_const, smul_eq_mul, mul_one] at counts
    have original := M.budget v.val
    omega

open Classical in
theorem free (M : BoundaryModel V) (c : BridgeCut M.graph) :
    (c.model M).marked c.root < (c.model M).opposite c.root := by
  simpa [model] using M.marked_le c.root.val

open BoundaryModel Bridge

variable (M : BoundaryModel V) (c : BridgeCut M.graph)

open Classical in
private theorem degree_restrict (h : V → Bool) (v : c.carrier) :
    M.monoDegree h v.val = (c.model M).monoDegree (fun w => h w.val) v +
      (if v = c.root then same (h v.val) (h c.tip) else 0) := by
  unfold monoDegree inside
  rw [c.sum_neighbors v (fun w => same (h v.val) (h w))]
  change _ = (_ + M.fixed v.val (h v.val)) + _
  simp only [model]
  omega

open Classical in
theorem valid_restrict_iff (h : V → Bool) :
    ((c.model M).cutSide c.root).asSide.valid (fun w => h w.val) (h c.tip) ↔
      ∀ v : c.carrier, M.monoDegree h v.val ≤ 1 := by
  change ((∀ v, v ≠ c.root → _) ∧ _) ↔ _
  constructor
  · rintro ⟨other, root⟩ v
    rw [degree_restrict M c]
    by_cases hv : v = c.root
    · subst v
      simpa [cutSide, same] using root
    · simpa [hv] using other v hv
  · intro all
    constructor
    · intro v hv
      simpa [degree_restrict M c h v, hv] using all v
    · simpa [degree_restrict M c h c.root, same, cutSide] using all c.root

open Classical in
/-- Restriction to the two sides of the actual cut is a bijection on
admissible colorings, with compatibility tested against the opposite root. -/
noncomputable def goodEquivJoint : Good M ≃
    Joint ((c.model M).cutSide c.root).asSide
      ((c.reverse.model M).cutSide c.reverse.root).asSide := by
  apply (Equiv.piEquivPiSubtypeProd (· ∈ c.carrier) (fun _ => Bool)).subtypeEquiv
  intro h
  change (∀ v, M.monoDegree h v ≤ 1) ↔
    ((c.model M).cutSide c.root).asSide.valid (fun w => h w.val) (h c.tip) ∧
    ((c.reverse.model M).cutSide c.reverse.root).asSide.valid
      (fun w => h w.val) (h c.reverse.tip)
  rw [valid_restrict_iff, valid_restrict_iff]
  constructor
  · exact fun all => ⟨fun v => all v.val, fun v => all v.val⟩
  · rintro ⟨left, right⟩ v
    by_cases hv : v ∈ c.carrier
    · exact left ⟨v, hv⟩
    · exact right ⟨v, hv⟩

open Classical in
theorem jointWeight_goodEquivJoint (h : Good M) :
    jointWeight _ _ (goodEquivJoint M c h) = M.weightedSum h.val := by
  classical
  change (∑ v : c.carrier, M.weight v.val * spin (h.val v.val)) +
    (∑ v : c.reverse.carrier, M.weight v.val * spin (h.val v.val)) = _
  convert Fintype.sum_subtype_add_sum_subtype (· ∈ c.carrier)
    (fun v => M.weight v * spin (h.val v)) using 2
  · congr 2
    exact Subsingleton.elim _ _
  · rfl

open Classical in
/-- The two contracted models have strictly fewer vertices for every
choice of the replacement port. -/
theorem card_lt : Fintype.card c.carrier < Fintype.card V :=
  Fintype.card_subtype_lt c.tip_outside

open Classical in
/-- Transfer the two induction bounds to the original graph. -/
theorem spectralStep (L : ℕ)
    (left : ∀ p, ((c.model M).contract c.root (c.free M) p).spectralStep L)
    (right : ∀ p,
      ((c.reverse.model M).contract c.reverse.root (c.reverse.free M) p).spectralStep L) :
    M.spectralStep L := by
  let e := goodEquivJoint M c
  have step := (c.model M).boundaryBridge (c.reverse.model M) c.root c.reverse.root
    (c.free M) (c.reverse.free M) L left right
  have weight (z) : M.weightedSum (e.symm z).val = jointWeight _ _ z := by
    rw [← jointWeight_goodEquivJoint M c (e.symm z)]
    exact congrArg _ (e.apply_symm_apply z)
  intro x y
  have walk := Relation.ReflTransGen.lift (r := fun a b =>
      (jointWeight _ _ b - jointWeight _ _ a).natAbs ≤ L)
    e.symm (p := fun a b => (M.weightedSum b.val - M.weightedSum a.val).natAbs ≤ L)
    (fun a b hab => by
      change (M.weightedSum (e.symm b).val - M.weightedSum (e.symm a).val).natAbs ≤ L
      rwa [weight, weight]) (e x) (e y) (step _ _)
  change Walk L (fun h : Good M => M.weightedSum h.val) (e.symm (e x)) (e.symm (e y)) at walk
  simpa only [Equiv.symm_apply_apply] using walk

end BridgeCut
end QuasiBisection
