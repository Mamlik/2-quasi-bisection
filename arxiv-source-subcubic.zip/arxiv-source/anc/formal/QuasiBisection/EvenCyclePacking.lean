module

public import QuasiBisection.CycleGraph
public import Mathlib.Data.Finset.Max

/-! A maximum packing of even cycles leaves no even cycle in its complement. -/

@[expose] public section

namespace QuasiBisection

open SimpleGraph

variable {V : Type*} (G : SimpleGraph V)

open Classical in
def EvenCycleSupport (S : Finset V) : Prop :=
  ∃ (x : V) (p : G.Walk x x), p.IsCycle ∧ Even p.length ∧ p.support.toFinset = S

def EvenPacking (F : Finset (Finset V)) : Prop :=
  (∀ S ∈ F, EvenCycleSupport G S) ∧ (F : Set (Finset V)).Pairwise Disjoint

def leftover (F : Finset (Finset V)) : Set V := {v | ∀ S ∈ F, v ∉ S}

/-- Maximality applies to cycles of the induced residue as well as to cycles
expressed in the original graph. No connectedness or degree bound is needed. -/
theorem exists_even_packing [Finite V] :
    ∃ F : Finset (Finset V), EvenPacking G F ∧
      ∀ (v : leftover F) (p : (G.induce (leftover F)).Walk v v), p.IsCycle → ¬ Even p.length := by
  classical
  let _ := Fintype.ofFinite V
  let packs := Finset.univ.filter (EvenPacking G)
  have empty : (∅ : Finset (Finset V)) ∈ packs := by simp [packs, EvenPacking]
  obtain ⟨F, hF, maxF⟩ := packs.exists_max_image Finset.card ⟨_, empty⟩
  have valid : EvenPacking G F := (Finset.mem_filter.mp hF).2
  refine ⟨F, valid, ?_⟩
  intro x p hp even
  let f := SimpleGraph.Embedding.induce (G := G) (leftover F)
  let q := p.map f.toHom
  let S := q.support.toFinset
  have witness : EvenCycleSupport G S :=
    ⟨_, q, hp.map f.injective, by simpa only [q, Walk.length_map] using even, rfl⟩
  have outside (v : V) (hv : v ∈ S) : v ∈ leftover F := by
    have mem : v ∈ p.support.map f.toHom := by
      simpa only [S, q, List.mem_toFinset, Walk.support_map] using hv
    obtain ⟨u, _, rfl⟩ := List.mem_map.mp mem
    exact u.property
  have fresh : S ∉ F := by
    intro old
    have start : x.val ∈ S := List.mem_toFinset.mpr q.start_mem_support
    exact outside x.val start S old start
  have larger : EvenPacking G (insert S F) := by
    constructor
    · intro T mem
      rcases Finset.mem_insert.mp mem with rfl | h
      · exact witness
      · exact valid.1 T h
    · rw [Finset.coe_insert, Set.pairwise_insert_of_symm]
      exact ⟨valid.2, fun T hT _ => Finset.disjoint_left.mpr (fun v hv => outside v hv T hT)⟩
  have bound := maxF (insert S F) (Finset.mem_filter.mpr ⟨Finset.mem_univ _, larger⟩)
  rw [Finset.card_insert_of_notMem fresh] at bound
  omega

end QuasiBisection
