module

public import QuasiBisection.SingleDefect
public import QuasiBisection.PortProfiles

/-! An open bridge end is represented by one reserved, unmarked opposite
slot. Supplying a fixed input replaces exactly that slot. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

open Bridge

variable {V : Type*} [Fintype V] (M : BoundaryModel V)

noncomputable def cutSide (r : V) : CutSide (V → Bool) where
  root h := h r
  otherMatches h := M.monoDegree h r
  otherVerticesOK h := ∀ v, v ≠ r → M.monoDegree h v ≤ 1
  weight := M.weightedSum

noncomputable def fill (r : V) (free : M.marked r < M.opposite r) (t : Bool) :
    BoundaryModel V := by
  classical
  exact {
    graph := M.graph
    fixed := fun v b => M.fixed v b + (if v = r ∧ b = t then 1 else 0)
    marked := M.marked
    opposite := fun v => if v = r then M.opposite v - 1 else M.opposite v
    marked_le := by
      intro v
      by_cases e : v = r
      · subst v
        simp only [↓reduceIte]
        omega
      · simpa only [ite_eq_right e] using M.marked_le v
    budget := by
      intro v
      by_cases e : v = r
      · subst v
        have base := M.budget r
        cases t <;> simp <;> omega
      · simpa [e] using M.budget v }

open Classical in
private theorem fill_degree (r : V) (free : M.marked r < M.opposite r) (t : Bool)
    (h : V → Bool) (v : V) :
    (M.fill r free t).monoDegree h v =
      M.monoDegree h v + (if v = r ∧ h v = t then 1 else 0) := by
  classical
  simp only [monoDegree, inside, fill, Nat.add_assoc]

theorem fill_valid (r : V) (free : M.marked r < M.opposite r)
    (h : V → Bool) (t : Bool) :
    (M.cutSide r).asSide.valid h t ↔ ∀ v, (M.fill r free t).monoDegree h v ≤ 1 := by
  classical
  constructor
  · rintro ⟨elsewhere, root⟩ v
    rw [M.fill_degree]
    by_cases e : v = r
    · subst v
      by_cases col : h r = t <;> simpa [cutSide, col] using root
    · simpa [e] using elsewhere v e
  · intro all
    constructor
    · intro v e
      simpa [M.fill_degree, e] using all v
    · by_cases col : h r = t <;> simpa [cutSide, M.fill_degree, col] using all r

/-- Concrete two-row profile through every admissible colouring of a cut
side. Single-defect repair is proved and consumed inside this theorem. -/
theorem boundaryProfiles (r : V) (free : M.marked r < M.opposite r) :
    ProfileThrough (M.cutSide r).asSide := by
  apply profiles_of_repair
  intro h t old invalid
  let N := M.fill r free (!t)
  have onlyRoot (v : V) (e : v ≠ r) : N.monoDegree h v ≤ 1 := by
    simpa [N, M.fill_degree, e] using old.1 v e
  have bad : 2 ≤ N.monoDegree h r := by
    by_contra! good
    apply invalid
    apply (M.fill_valid r free h (!t)).2
    intro v
    by_cases e : v = r
    · subst v
      change N.monoDegree h r ≤ 1
      omega
    · exact onlyRoot v e
  obtain ⟨g, _, valid, root, delta⟩ := N.single_repair h r bad onlyRoot
  exact ⟨g, (M.fill_valid r free g (!t)).2 valid, root, delta⟩

end QuasiBisection.BoundaryModel
