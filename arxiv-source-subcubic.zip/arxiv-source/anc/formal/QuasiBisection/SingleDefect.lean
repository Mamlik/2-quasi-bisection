module

public import QuasiBisection.DefectRepair

/-! The one-defect chain, including its final root colour. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

variable {V : Type*} [Fintype V] (M : BoundaryModel V)

noncomputable def weightedSum (h : V → Bool) : ℤ := ∑ v, M.weight v * spin (h v)

private theorem spin_flip (t : Bool) : spin (!t) = -spin t := by cases t <;> rfl

private theorem sum_flip (h : V → Bool) (r : V) :
    M.weightedSum (flip h r) = M.weightedSum h - 2 * M.weight r * spin (h r) := by
  classical
  have outside : (∑ v ∈ Finset.univ.erase r, M.weight v * spin (flip h r v)) =
      ∑ v ∈ Finset.univ.erase r, M.weight v * spin (h v) := by
    apply Finset.sum_congr rfl
    intro v hv
    simp [flip, Finset.ne_of_mem_erase hv]
  unfold weightedSum
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ r),
    ← Finset.add_sum_erase _ (fun v => M.weight v * spin (h v)) (Finset.mem_univ r), outside]
  simp only [flip, ↓reduceIte, spin_flip, Int.mul_neg, Int.mul_assoc]
  omega

private theorem degree_as_sum (h : V → Bool) (v : V) :
    M.monoDegree h v = (∑ u, M.edgeHit h v u) + M.fixed v (h v) := by
  simp only [monoDegree, inside, neighbors, Finset.sum_filter, edgeHit]

private theorem degree_change (h : V → Bool) {v r : V} (ne : v ≠ r) :
    M.monoDegree (flip h r) v + M.edgeHit h r v =
      M.monoDegree h v + M.edgeHit (flip h r) r v := by
  classical
  have outside : (∑ u ∈ Finset.univ.erase r, M.edgeHit (flip h r) v u) =
      ∑ u ∈ Finset.univ.erase r, M.edgeHit h v u := by
    apply Finset.sum_congr rfl
    intro u hu
    simp only [edgeHit, flip, ite_eq_right ne, ite_eq_right (Finset.ne_of_mem_erase hu)]
  rw [M.degree_as_sum, M.degree_as_sum,
    ← Finset.add_sum_erase _ _ (Finset.mem_univ r),
    ← Finset.add_sum_erase _ (M.edgeHit h v) (Finset.mem_univ r), outside,
    M.hit_symm h v r, M.hit_symm (flip h r) v r]
  simp only [flip, ite_eq_right ne]
  omega

private theorem pair_le_degree (h : V → Bool) (r : V) {u v : V} (hne : u ≠ v) :
    M.edgeHit h r u + M.edgeHit h r v ≤ M.monoDegree h r := by
  classical
  rw [M.degree_as_sum, ← Finset.add_sum_erase _ _ (Finset.mem_univ v)]
  have hu : u ∈ Finset.univ.erase v := Finset.mem_erase.mpr ⟨hne, Finset.mem_univ _⟩
  rw [← Finset.add_sum_erase _ _ hu]
  omega

private theorem hit_le_one (h : V → Bool) (r v : V) : M.edgeHit h r v ≤ 1 := by
  classical
  unfold edgeHit same
  split
  · split <;> decide
  · decide

private theorem hit_info (h : V → Bool) {r v : V} (one : M.edgeHit h r v = 1) :
    M.graph.Adj r v ∧ h r = h v := by
  classical
  by_cases edge : M.graph.Adj r v <;> by_cases eq : h r = h v <;>
    simp_all [edgeHit, same]

/-- Other vertices that can safely be promised their current colour. -/
def Protected (h : V → Bool) (r v : V) : Prop :=
  v ≠ r ∧ (M.monoDegree h v = 0 ∨ (M.monoDegree h v = 1 ∧ M.edgeHit h r v = 1))

/-- Every subsequent flip fixes the root and the vertices already protected. -/
def AfterFirst (h : V → Bool) (r : V) (a b : V → Bool) : Prop :=
  M.RepairStep a b ∧ b r = a r ∧ ∀ v, M.Protected h r v → b v = a v

theorem single_repair_trace (h : V → Bool) (r : V) (bad : 2 ≤ M.monoDegree h r)
    (onlyBad : ∀ v, v ≠ r → M.monoDegree h v ≤ 1) :
    ∃ g, Relation.ReflTransGen (M.AfterFirst h r) (flip h r) g ∧ (∀ v, M.monoDegree g v ≤ 1) ∧
      g r = !(h r) ∧ (M.weightedSum g = M.weightedSum h ∨
        M.weightedSum g = M.weightedSum h - 2 * spin (h r)) ∧
      ∀ v, M.Protected h r v → g v = h v := by
  classical
  induction h using M.repair_wellFounded.induction generalizing r with
  | h h ih =>
    let next := flip h r
    have step : M.RepairStep h next := ⟨r, bad, rfl⟩
    have rootBound : M.monoDegree next r ≤ 1 := by have := M.flip_root h r; dsimp [next]; omega
    have atRoot : next r = !(h r) := by simp [next, flip]
    have elsewhere (v : V) (ne : v ≠ r) : next v = h v := by simp [next, flip, ne]
    obtain ⟨weights, propagate⟩ := M.defect_weights h r bad
    have diff : M.weightedSum next =
        M.weightedSum h - 2 * M.weight r * spin (h r) := M.sum_flip h r
    by_cases done : ∀ v, M.monoDegree next v ≤ 1
    · refine ⟨next, .refl, done, atRoot, ?_, fun v hv => elsewhere v hv.1⟩
      rcases weights with w | w
      · exact Or.inl (by simpa only [w, Int.mul_zero, Int.zero_mul, Int.sub_zero] using diff)
      · exact Or.inr (by simpa only [w, Int.mul_one] using diff)
    obtain ⟨y, hy⟩ := Classical.not_forall.mp done
    have yr : y ≠ r := by rintro rfl; omega
    have balanceY := M.degree_change h yr
    change M.monoDegree next y + M.edgeHit h r y =
      M.monoDegree h y + M.edgeHit next r y at balanceY
    have oldY := onlyBad y yr
    have capY := M.hit_le_one next r y
    have hitY : M.edgeHit next r y = 1 := by omega
    have sumY : M.edgeHit next r y ≤ M.monoDegree next r := by
      have := M.pair_le_degree next r yr
      omega
    have weightOne := propagate (show 0 < M.monoDegree next r by omega)
    have noOther (v : V) (vy : v ≠ y) : M.edgeHit next r v = 0 := by
      have := M.pair_le_degree next r vy
      omega
    have onlyY (v : V) (vy : v ≠ y) : M.monoDegree next v ≤ 1 := by
      by_cases vr : v = r
      · simpa only [vr] using rootBound
      have eq := M.degree_change h vr
      change M.monoDegree next v + _ = _ + M.edgeHit next r v at eq
      have := onlyBad v vr
      have := noOther v vy
      omega
    have protectR : M.Protected next y r := by
      refine ⟨yr.symm, Or.inr ⟨by omega, ?_⟩⟩
      rw [M.hit_symm next y r, hitY]
    have protectOld (v : V) (hv : M.Protected h r v) : M.Protected next y v := by
      obtain ⟨vr, zeroOrOne⟩ := hv
      have eq := M.degree_change h vr
      change M.monoDegree next v + M.edgeHit h r v = _ + M.edgeHit next r v at eq
      have vy : v ≠ y := by
        rintro rfl
        rcases zeroOrOne with zero | ⟨one, hit⟩ <;> omega
      refine ⟨vy, Or.inl ?_⟩
      have := noOther v vy
      rcases zeroOrOne with zero | ⟨one, hit⟩ <;> omega
    obtain ⟨g, walk, stable, _, delta, keep⟩ :=
      ih next step y (by omega) onlyY
    have walk' : Relation.ReflTransGen (M.AfterFirst h r) (flip next y) g :=
      Relation.ReflTransGen.mono (fun _ _ tail =>
        ⟨tail.1, tail.2.2 r protectR, fun v hv => tail.2.2 v (protectOld v hv)⟩)
        _ _ walk
    have first : M.AfterFirst h r next (flip next y) := by
      refine ⟨⟨y, by omega, rfl⟩, by simp [flip, yr.symm], ?_⟩
      intro v hv
      simp [flip, (protectOld v hv).1]
    refine ⟨g, walk'.head first, stable, (keep r protectR).trans atRoot, ?_,
      fun v hv => (keep v (protectOld v hv)).trans (elsewhere v hv.1)⟩
    have alternate : next y = !(h r) := (M.hit_info next hitY).2.symm.trans atRoot
    rw [weightOne, Int.mul_one] at diff
    rcases delta with unchanged | changed
    · exact Or.inr (unchanged.trans diff)
    · rw [alternate, spin_flip] at changed
      exact Or.inl (by omega)

/-- A defect of weight zero has no successor. Flipping it preserves
the sum and restores admissibility. -/
theorem repair_zero_weight (h : V → Bool) (r : V) (zero : M.weight r = 0)
    (bad : 2 ≤ M.monoDegree h r) (onlyBad : ∀ v, v ≠ r → M.monoDegree h v ≤ 1) :
    (∀ v, M.monoDegree (flip h r) v ≤ 1) ∧ M.weightedSum (flip h r) = M.weightedSum h := by
  obtain ⟨_, propagate⟩ := M.defect_weights h r bad
  have root : M.monoDegree (flip h r) r = 0 := by
    by_contra! pos
    have := propagate (by omega)
    omega
  refine ⟨?_, by simp [M.sum_flip, zero]⟩
  intro v
  by_cases eq : v = r
  · simpa [eq] using root.le.trans (by decide : 0 ≤ 1)
  · have hits := M.pair_le_degree (flip h r) r eq
    have change := M.degree_change h eq
    have old := onlyBad v eq
    omega

/-- The unique initially defective root changes colour and the terminal
weighted sum has one of two specified values. -/
theorem single_repair (h : V → Bool) (r : V) (bad : 2 ≤ M.monoDegree h r)
    (onlyBad : ∀ v, v ≠ r → M.monoDegree h v ≤ 1) :
    ∃ g, Relation.ReflTransGen M.RepairStep h g ∧ (∀ v, M.monoDegree g v ≤ 1) ∧
      g r = !(h r) ∧ (M.weightedSum g = M.weightedSum h ∨
        M.weightedSum g = M.weightedSum h - 2 * spin (h r)) := by
  obtain ⟨g, path, hg, root, delta, _⟩ := M.single_repair_trace h r bad onlyBad
  have tail := Relation.ReflTransGen.mono (r := M.AfterFirst h r)
    (p := M.RepairStep) (fun _ _ step => step.1) _ _ path
  exact ⟨g, tail.head ⟨r, bad, rfl⟩, hg, root, delta⟩

/-- A chain started in a coloring with several defects follows only the
newly matching edge. A surviving defect retains its color and loses at
least its original match with the starting vertex, if it had one. -/
theorem repair_among_defects (unit : ∀ v, M.weight v = 1) (h : V → Bool) (r : V)
    (bad : 2 ≤ M.monoDegree h r) :
    ∃ g, (M.weightedSum g = M.weightedSum h ∨
        M.weightedSum g = M.weightedSum h - 2 * spin (h r)) ∧
      ∀ v, 2 ≤ M.monoDegree g v → v ≠ r ∧ g v = h v ∧
        M.monoDegree g v + M.edgeHit h r v ≤ M.monoDegree h v := by
  classical
  induction h using M.repair_wellFounded.induction generalizing r with
  | h h ih =>
    let k := flip h r
    have root : M.monoDegree k r ≤ 1 := by
      have := M.flip_root h r
      dsimp [k]
      omega
    have drop := M.sum_flip h r
    rw [unit, Int.mul_one] at drop
    have survive (v : V) (hv : 2 ≤ M.monoDegree k v) (zero : M.edgeHit k r v = 0) :
        v ≠ r ∧ k v = h v ∧ M.monoDegree k v + M.edgeHit h r v ≤ M.monoDegree h v := by
      have ne : v ≠ r := by rintro rfl; omega
      have count := M.degree_change h ne
      change M.monoDegree k v + M.edgeHit h r v = M.monoDegree h v + M.edgeHit k r v at count
      exact ⟨ne, by simp [k, flip, ne], by omega⟩
    by_cases successor : ∃ y, 2 ≤ M.monoDegree k y ∧ M.edgeHit k r y = 1
    · obtain ⟨y, hy, hit⟩ := successor
      obtain ⟨g, diff, rest⟩ := ih k ⟨r, bad, rfl⟩ y hy
      have color : k y = !(h r) := (M.hit_info k hit).2.symm.trans (by simp [k, flip])
      refine ⟨g, ?_, fun v hv => ?_⟩
      · rcases diff with eq | eq
        · exact Or.inr (eq.trans drop)
        · rw [color, spin_flip] at eq
          change M.weightedSum k = _ at drop
          exact Or.inl (by omega)
      · obtain ⟨ne, sameColor, deg⟩ := rest v hv
        have two : 2 ≤ M.monoDegree k v := by omega
        have cap := M.pair_le_degree k r ne
        obtain ⟨vr, col, bound⟩ := survive v two (by omega)
        exact ⟨vr, sameColor.trans col, by omega⟩
    · refine ⟨k, Or.inr drop, fun v hv => survive v hv ?_⟩
      have cap := M.hit_le_one k r v
      have ne : M.edgeHit k r v ≠ 1 := fun hit => successor ⟨v, hv, hit⟩
      omega

end QuasiBisection.BoundaryModel
