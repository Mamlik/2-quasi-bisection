module

public import QuasiBisection.BridgeGluing

/-! Extracting two rows from the response to a reversed bridge input. -/

@[expose] public section

namespace QuasiBisection.Bridge

/-- The other two slots at the root and all other vertices are independent
of the external input. -/
structure CutSide (X : Type*) where
  root : X → Bool
  otherMatches : X → ℕ
  otherVerticesOK : X → Prop
  weight : X → ℤ

def CutSide.asSide {X : Type*} (A : CutSide X) : Side X where
  root := A.root
  weight := A.weight
  valid x t := A.otherVerticesOK x ∧
    A.otherMatches x + (if A.root x = t then 1 else 0) ≤ 1

/-- The conclusion required from the single-defect repair on this side. -/
def CutSide.Repairs {X : Type*} (A : CutSide X) : Prop :=
  ∀ x t, A.asSide.valid x t → ¬ A.asSide.valid x (!t) →
    ∃ y, A.asSide.valid y (!t) ∧ A.root y = !(A.root x) ∧
      (A.weight y = A.weight x ∨ A.weight y = A.weight x - 2 * spin (A.root x))

private theorem twoRows {X : Type*} (A : Side X) (x y : X) (t : Bool)
    (p : Port) (c : ℤ) (hx : A.valid x t) (hy : A.valid y (!t))
    (ox : A.root x = p.output t) (oy : A.root y = p.output (!t))
    (wx : A.weight x = c + p.offset t) (wy : A.weight y = c + p.offset (!t)) :
    ∃ profile : Profile A, profile.row t = x := by
  let row := fun u => if u = t then x else y
  have cover (P : Bool → X → Prop) (h₁ : P t x) (h₂ : P (!t) y) :
      ∀ u, P u (row u) := by
    intro u
    cases t <;> cases u <;> first | exact h₁ | exact h₂
  exact ⟨⟨p, row, cover (fun u z => A.valid z u) hx hy,
    cover (fun u z => A.root z = p.output u) ox oy, c,
    cover (fun u z => A.weight z = c + p.offset u) wx wy⟩, by simp [row]⟩

theorem profiles_of_repair {X : Type*} (A : CutSide X) (repair : A.Repairs) :
    ProfileThrough A.asSide := by
  intro x t hx
  classical
  by_cases hy : A.asSide.valid x (!t)
  · exact twoRows _ x x t (.fixed (A.root x)) (A.weight x) hx hy rfl rfl
      (by simp [CutSide.asSide, Port.offset]) (by simp [CutSide.asSide, Port.offset])
  have root : A.root x = !t := by
    by_contra hn
    apply hy
    exact ⟨hx.1, by
      have h := hx.2
      simp only [ite_eq_right hn, Nat.add_zero]
      omega⟩
  obtain ⟨y, hy', flip, wy | wy⟩ := repair x t hx hy
  · exact twoRows _ x y t (.opposite false) (A.weight x) hx hy' root
      (flip.trans (congrArg Bool.not root))
      (by simp [CutSide.asSide, Port.offset]) (by simpa [CutSide.asSide, Port.offset] using wy)
  · apply twoRows _ x y t (.opposite true) (A.weight x + spin t) hx hy' root
      (flip.trans (congrArg Bool.not root))
    · change A.weight x = A.weight x + spin t + -spin t
      omega
    · change A.weight y = A.weight x + spin t + -spin (!t)
      rw [root] at wy
      cases t <;> simp only [Bool.not_false, Bool.not_true, spin, ite_true, ite_false,
        Bool.false_eq_true] at * <;> omega

end QuasiBisection.Bridge
