module

public import QuasiBisection.CycleGraph

/-! The gap bound for every connected subcubic cactus, by bridge induction. -/

@[expose] public section

namespace QuasiBisection

open SimpleGraph
open scoped Sym2

/-- Two simple cycles sharing an edge have identical edge sets.
The choice of starting vertex and direction is immaterial. -/
def CactusCycles {V : Type*} (G : SimpleGraph V) : Prop :=
  ∀ {x y : V} (p : G.Walk x x) (q : G.Walk y y), p.IsCycle → q.IsCycle →
    ∀ e, e ∈ p.edges → e ∈ q.edges → ∀ k, k ∈ p.edges → k ∈ q.edges

theorem CactusCycles.induce {V : Type*} {G : SimpleGraph V} (h : CactusCycles G) (S : Set V) :
    CactusCycles (G.induce S) := by
  let f := SimpleGraph.Embedding.induce (G := G) S
  intro x y p q hp hq e ep eq k kp
  have mem {a b : S} (w : (G.induce S).Walk a b) (t : Sym2 S) :
      Sym2.map f.toHom t ∈ (w.map f.toHom).edges ↔ t ∈ w.edges := by
    rw [Walk.edges_map, List.mem_map]
    constructor
    · rintro ⟨z, hz, he⟩
      exact (Sym2.map.injective f.injective he) ▸ hz
    · exact fun ht => ⟨t, ht, rfl⟩
  exact (mem q k).mp (h _ _ (hp.map f.injective) (hq.map f.injective) _
    ((mem p e).mpr ep) ((mem q e).mpr eq) _ ((mem p k).mpr kp))

namespace BoundaryModel

private theorem neighbor_count {V : Type*} [Fintype V] (M : BoundaryModel V) (a : V) :
    (M.graph.neighborSet a).ncard = (neighbors M.graph a).card := by
  classical
  have sets : (↑(neighbors M.graph a) : Set V) = M.graph.neighborSet a := by
    ext w
    simp [neighbors]
  rw [← sets, Set.ncard_coe_finset]

/-- In a bridgeless subcubic cactus, every edge at a vertex of a chosen
cycle lies on that cycle. Two cycles through a vertex of degree at most three
use a common incident edge. -/
private theorem cycle_closed {V : Type*} [Fintype V] (M : BoundaryModel V)
    (cactus : CactusCycles M.graph)
    (bridgeless : ∀ a b, M.graph.Adj a b → ¬ M.graph.IsBridge s(a,b))
    {x : V} (p : M.graph.Walk x x) (hp : p.IsCycle) {a b : V}
    (onCycle : a ∈ p.support) (adj : M.graph.Adj a b) : p.toSubgraph.Adj a b := by
  classical
  have notAll := (SimpleGraph.isBridge_iff_forall_cycle_notMem
    (show s(a,b) ∈ M.graph.edgeSet from adj)).not.mp (bridgeless _ _ adj)
  push Not at notAll
  obtain ⟨y, q, hq, edge⟩ := notAll
  have pc := hp.ncard_neighborSet_toSubgraph_eq_two onCycle
  have qc := hq.ncard_neighborSet_toSubgraph_eq_two (q.fst_mem_support_of_mem_edges edge)
  have cap := Set.ncard_le_ncard (Set.union_subset (p.toSubgraph.neighborSet_subset a)
    (q.toSubgraph.neighborSet_subset a))
  rw [M.neighbor_count] at cap
  have budget := M.budget a
  have common : ((p.toSubgraph.neighborSet a) ∩ (q.toSubgraph.neighborSet a)).Nonempty := by
    apply Set.nonempty_of_ncard_ne_zero
    have := Set.ncard_union_add_ncard_inter
      (p.toSubgraph.neighborSet a) (q.toSubgraph.neighborSet a)
    omega
  obtain ⟨z, pz, qz⟩ := common
  apply Walk.adj_toSubgraph_iff_mem_edges.mpr
  exact cactus q p hq hp s(a,z) (Walk.adj_toSubgraph_iff_mem_edges.mp qz)
    (Walk.adj_toSubgraph_iff_mem_edges.mp pz) _ edge

/-- All fixed and opposite boundary positions and their allowed
marks are quantified by the boundary model. -/
theorem cactus_step_four {V : Type*} [Fintype V] (M : BoundaryModel V)
    (conn : M.graph.Connected) (cactus : CactusCycles M.graph) : M.spectralStep 4 := by
  classical
  by_cases bridge : ∃ x y, M.graph.Adj x y ∧ M.graph.IsBridge s(x,y)
  · obtain ⟨x, y, adj, hb⟩ := bridge
    let c := BridgeCut.ofIsBridge adj hb
    have side (d : BridgeCut M.graph) (port : Bridge.Port) :
        ((d.model M).contract d.root (d.free M) port).spectralStep 4 := by
      apply cactus_step_four
      · rw [contract_graph]
        exact d.connected_induce conn
      · rw [contract_graph]
        exact cactus.induce d.carrier
    exact c.spectralStep M 4 (side c) (side c.reverse)
  · by_cases forest : M.graph.IsAcyclic
    · exact M.forest_step_four forest
    obtain ⟨x, p, hp⟩ := (SimpleGraph.not_isAcyclic_iff_exists_isCycle).mp forest
    have closed {a b : V} (ha : a ∈ p.support) (edge : M.graph.Adj a b) : p.toSubgraph.Adj a b :=
      M.cycle_closed cactus (fun u v adj hb => bridge ⟨u, v, adj, hb⟩) p hp ha edge
    apply M.cycle_step_four conn
    intro v
    have path := (SimpleGraph.reachable_iff_reflTransGen (G := M.graph) x v).mp (conn x v)
    have spans : v ∈ p.support := by
      induction path with
      | refl => exact p.start_mem_support
      | tail _ adj ih =>
        exact p.mem_verts_toSubgraph.mp (p.toSubgraph.edge_vert (closed ih adj).symm)
    have sets : M.graph.neighborSet v = p.toSubgraph.neighborSet v :=
      Set.Subset.antisymm (fun _ adj => closed spans adj) (p.toSubgraph.neighborSet_subset v)
    rw [← M.neighbor_count, sets, hp.ncard_neighborSet_toSubgraph_eq_two spans]
termination_by Fintype.card V
decreasing_by exact d.card_lt M

end BoundaryModel
end QuasiBisection
