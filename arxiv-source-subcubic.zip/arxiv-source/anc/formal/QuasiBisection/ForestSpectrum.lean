module

public import QuasiBisection.BridgeCut
public import Mathlib.Combinatorics.SimpleGraph.Acyclic

/-! The sharp uniform step bound for forests and its refinement for paths
without marked slots. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

open Bridge

variable {V : Type*} [Fintype V] (M : BoundaryModel V)

/-- For a graph without edges the vertex colors can be changed independently. -/
private theorem edgeless_step (noEdge : ∀ v w, ¬ M.graph.Adj v w) (n : ℕ)
    (bound : ∀ v, M.marked v ≤ n + 2) : M.spectralStep (2 * (n + 1)) := by
  classical
  intro f g
  have degree (h : V → Bool) (v : V) : M.monoDegree h v = M.fixed v (h v) := by
    simp [monoDegree, inside, neighbors, noEdge]
  let mix (s : Finset V) : Good M := ⟨fun v => if v ∈ s then g.val v else f.val v, by
    intro v
    rw [degree]
    by_cases hv : v ∈ s
    · simpa [hv, degree] using g.property v
    · simpa [hv, degree] using f.property v⟩
  have walk (s : Finset V) : Walk (2 * (n + 1)) (fun h : Good M => M.weightedSum h.val) f
      (mix s) := by
    induction s using Finset.induction_on with
    | empty =>
      have eq : mix ∅ = f := Subtype.ext (by funext v; simp [mix])
      rw [eq]
      exact .refl
    | @insert r s hr ih =>
      apply ih.tail
      change (M.weightedSum (mix (insert r s)).val - M.weightedSum (mix s).val).natAbs ≤ _
      unfold weightedSum
      rw [← Finset.sum_sub_distrib, Finset.sum_eq_single r]
      · have hb := bound r
        simp only [mix, Finset.mem_insert_self, ↓reduceIte, hr, weight]
        cases g.val r <;> cases f.val r <;> simp [spin] <;> omega
      · intro v _ hv
        simp [mix, hv]
      · simp
  have eq : mix Finset.univ = g := Subtype.ext (by funext v; simp [mix])
  simpa only [eq] using walk Finset.univ

theorem contract_graph (r : V) (free : M.marked r < M.opposite r) (p : Port) :
    (M.contract r free p).graph = M.graph := by
  cases p with
  | fixed => rfl
  | opposite m => cases m <;> rfl

open Classical in
private theorem contract_marked_le (r : V) (free : M.marked r < M.opposite r) (p : Port) (v : V) :
    (M.contract r free p).marked v ≤ M.marked v + if v = r then 1 else 0 := by
  cases p with
  | fixed => exact Nat.le_add_right _ _
  | opposite m =>
    cases m with
    | false => exact Nat.le_add_right _ _
    | true => exact Nat.le_refl _

open Classical in
private theorem cut_bound (c : BridgeCut M.graph) (p : Port) (k : ℕ)
    (bound : ∀ v, M.marked v + (neighbors M.graph v).card ≤ k) (v : c.carrier) :
    let N := (c.model M).contract c.root (c.free M) p
    N.marked v + (neighbors N.graph v).card ≤ k := by
  have deg := c.sum_neighbors v (fun _ => 1)
  simp only [Finset.sum_const, smul_eq_mul, mul_one] at deg
  have marks := contract_marked_le (c.model M) c.root (c.free M) p v
  change _ ≤ M.marked v.val + _ at marks
  dsimp only
  rw [contract_graph]
  change _ + (neighbors (M.graph.induce c.carrier) v).card ≤ k
  have old := bound v.val
  by_cases hv : v = c.root
  · simp only [ite_eq_left hv] at deg marks
    omega
  · simp only [ite_eq_right hv] at deg marks
    omega

/-- The degree plus the number of marked slots never increases under a
contraction. With ceiling two one obtains step two; ceiling three gives four. -/
theorem forest_step_of_bound {V : Type*} [Fintype V] (M : BoundaryModel V)
    (forest : M.graph.IsAcyclic) (n : ℕ)
    (bound : ∀ v, M.marked v + (neighbors M.graph v).card ≤ n + 2) :
    M.spectralStep (2 * (n + 1)) := by
  classical
  by_cases edge : ∃ x y, M.graph.Adj x y
  · obtain ⟨x, y, adj⟩ := edge
    let c := BridgeCut.ofIsBridge adj
      (SimpleGraph.isAcyclic_iff_forall_isBridge.mp forest (by simpa using adj))
    have side (d : BridgeCut M.graph) (p : Port) :
        ((d.model M).contract d.root (d.free M) p).spectralStep (2 * (n + 1)) := by
      apply forest_step_of_bound ((d.model M).contract d.root (d.free M) p)
      · rw [contract_graph]
        exact forest.induce d.carrier
      · exact cut_bound M d p _ bound
    exact c.spectralStep M _ (side c) (side c.reverse)
  · apply M.edgeless_step (fun v w h => edge ⟨v, w, h⟩)
    intro v
    have := bound v
    omega
termination_by Fintype.card V
decreasing_by exact d.card_lt M

/-- The weighted spectrum of every subcubic forest has step at most four. -/
theorem forest_step_four (forest : M.graph.IsAcyclic) : M.spectralStep 4 := by
  apply M.forest_step_of_bound forest 1
  intro v
  have := M.marked_le v
  have := M.budget v
  omega

/-- Step two on paths without initial marks, and more generally on forests
where each vertex has at most two marks and internal incidences in total. -/
theorem forest_step_two (forest : M.graph.IsAcyclic)
    (bound : ∀ v, M.marked v + (neighbors M.graph v).card ≤ 2) : M.spectralStep 2 :=
  M.forest_step_of_bound forest 0 bound

end QuasiBisection.BoundaryModel
