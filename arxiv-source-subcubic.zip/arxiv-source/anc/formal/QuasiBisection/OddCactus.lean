module

public import QuasiBisection.CactusSpectrum
public import QuasiBisection.EvenCyclePacking

/-! A graph in which every simple cycle is odd satisfies the cactus condition. -/

@[expose] public section

namespace QuasiBisection

open SimpleGraph

variable {V : Type*} {G : SimpleGraph V}

private theorem two_arcs {x a b : V} {c : G.Walk x x} (cyc : c.IsCycle)
    (ha : a ∈ c.support) (hb : b ∈ c.support) (ne : a ≠ b) :
    ∃ (p : G.Walk a b) (q : G.Walk b a), p.IsPath ∧ q.IsPath ∧
      p.support ⊆ c.support ∧ q.support ⊆ c.support ∧
      (∀ e, e ∈ c.edges ↔ e ∈ p.edges ∨ e ∈ q.edges) ∧ p.length + q.length = c.length := by
  classical
  let t := c.rotate a ha
  have onB : b ∈ t.support := (c.mem_support_rotate_iff a ha).mpr hb
  let p := t.takeUntil b onB
  let q := t.dropUntil b onB
  have eq : p.append q = t := t.take_spec onB
  have cyc' : (p.append q).IsCycle := eq ▸ cyc.rotate ha
  have verts (v : V) : v ∈ t.support ↔ v ∈ c.support := c.mem_support_rotate_iff a ha
  refine ⟨p, q, cyc'.isPath_of_append_left (Walk.not_nil_of_ne ne.symm),
    cyc'.isPath_of_append_right (Walk.not_nil_of_ne ne), ?_, ?_, ?_, ?_⟩
  · exact fun _ hv => (verts _).mp ((t.isSubwalk_takeUntil onB).support_subset hv)
  · exact fun _ hv => (verts _).mp ((t.isSubwalk_dropUntil onB).support_subset hv)
  · intro e
    rw [← (c.rotate_edges a ha).perm.mem_iff]
    change e ∈ t.edges ↔ _
    rw [← eq, Walk.edges_append, List.mem_append]
  · simpa only [Walk.length_append, t, Walk.length_rotate] using congrArg Walk.length eq

private theorem tail_excludes_start {a b : V} {p : G.Walk a b} (hp : p.IsPath) :
    a ∉ p.support.tail := by
  have nodup := hp.support_nodup
  rw [← p.cons_tail_support, List.nodup_cons] at nodup
  exact nodup.1

/-- An ear internally disjoint from an odd cycle makes an even cycle with
one of its two arcs. A single-edge ear must be distinct from an arc. -/
private theorem ear_obstruction {x a b : V} {c : G.Walk x x} (cyc : c.IsCycle)
    (odd : ∀ (v : V) (w : G.Walk v v), w.IsCycle → ¬ Even w.length)
    {p : G.Walk a b} (hp : p.IsPath) (ha : a ∈ c.support) (hb : b ∈ c.support)
    (ne : a ≠ b) (inside : ∀ z ∈ p.support, z ∈ c.support → z = a ∨ z = b)
    {k : Sym2 V} (kp : k ∈ p.edges) (kc : k ∉ c.edges) : False := by
  obtain ⟨l, r, hl, hr, vl, vr, edges, len⟩ := two_arcs cyc ha hb ne
  have close (q : G.Walk b a) (hq : q.IsPath) (verts : q.support ⊆ c.support)
      (absent : k ∉ q.edges) : (p.append q).IsCycle := by
    apply hp.isCycle_append hq
    · intro z hz hqz
      rcases inside z (List.mem_of_mem_tail hz) (verts (List.mem_of_mem_tail hqz)) with e | e
      · exact tail_excludes_start hp (e ▸ hz)
      · exact tail_excludes_start hq (e ▸ hqz)
    · by_contra! short
      have eq : p = q.reverse := Walk.eq_of_length_le_one short.1 (by simpa using short.2)
      exact absent (by simpa [eq] using kp)
  have first := close l.reverse hl.reverse (by simpa using vl)
    (by simpa using (show k ∉ l.edges from fun h => kc ((edges k).mpr (Or.inl h))))
  have second := close r hr vr (fun h => kc ((edges k).mpr (Or.inr h)))
  have o₁ := odd _ _ first
  have o₂ := odd _ _ second
  have o₃ := odd _ _ cyc
  simp only [Walk.length_append, Walk.length_reverse, Nat.not_even_iff] at o₁ o₂ o₃
  omega

/-- Split at any internal return to the cycle until the remaining path is an ear. -/
private theorem path_on_odd_cycle {x : V} {c : G.Walk x x} (cyc : c.IsCycle)
    (odd : ∀ (v : V) (w : G.Walk v v), w.IsCycle → ¬ Even w.length)
    {a b : V} (p : G.Walk a b) (hp : p.IsPath) (ha : a ∈ c.support) (hb : b ∈ c.support)
    {k : Sym2 V} (kp : k ∈ p.edges) : k ∈ c.edges := by
  classical
  by_cases hit : ∃ z ∈ p.support, z ∈ c.support ∧ z ≠ a ∧ z ≠ b
  · obtain ⟨z, hz, hc, za, zb⟩ := hit
    have mem := kp
    rw [← p.take_spec hz, Walk.edges_append, List.mem_append] at mem
    rcases mem with left | right
    · exact path_on_odd_cycle cyc odd _ (hp.takeUntil hz) ha hc left
    · exact path_on_odd_cycle cyc odd _ (hp.dropUntil hz) hc hb right
  · by_contra outside
    have ne : a ≠ b := by
      rintro rfl
      rw [Walk.eq_nil_iff_nil.mpr (Walk.isPath_iff_nil.mp hp)] at kp
      exact List.not_mem_nil kp
    exact ear_obstruction cyc odd hp ha hb ne (fun z hz hc => by
      by_contra! miss
      exact hit ⟨z, hz, hc, miss.1, miss.2⟩) kp outside
termination_by p.length
decreasing_by
  all_goals
    classical
    first
    | exact Walk.length_takeUntil_lt_length hz zb
    | exact Walk.length_dropUntil_lt_length hz za

theorem cactusCycles_of_no_even_cycle
    (odd : ∀ (v : V) (w : G.Walk v v), w.IsCycle → ¬ Even w.length) : CactusCycles G := by
  intro x y p q hp hq e ep eq k kp
  obtain ⟨a, b⟩ := e
  obtain ⟨l, r, hl, hr, _, _, edges, _⟩ := two_arcs hp
    (p.fst_mem_support_of_mem_edges ep) (p.snd_mem_support_of_mem_edges ep)
    (p.adj_of_mem_edges ep).ne
  have ha := q.fst_mem_support_of_mem_edges eq
  have hb := q.snd_mem_support_of_mem_edges eq
  rcases (edges k).mp kp with left | right
  · exact path_on_odd_cycle hq odd l hl ha hb left
  · exact path_on_odd_cycle hq odd r hr hb ha right

theorem exists_even_packing_cactus (G : SimpleGraph V) [Finite V] :
    ∃ F, EvenPacking G F ∧ CactusCycles (G.induce (leftover F)) ∧
      ∀ (v : leftover F) (p : (G.induce (leftover F)).Walk v v), p.IsCycle → ¬ Even p.length := by
  obtain ⟨F, valid, residue⟩ := exists_even_packing G
  exact ⟨F, valid, cactusCycles_of_no_even_cycle residue, residue⟩

end QuasiBisection
