module

public import QuasiBisection.ForestSpectrum
public import Mathlib.Data.Fintype.BigOperators

/-! Opening a graph at one vertex. Each former neighbor receives a fixed
boundary sign that may be changed independently of the other neighbors. -/

@[expose] public section

namespace QuasiBisection.BoundaryModel

variable {V : Type*} [Fintype V] (M : BoundaryModel V) (r : V)

abbrev Away (r : V) := {v : V // v ≠ r}

open Classical in
theorem sum_neighbors_away (v : Away r) (f : V → ℕ) :
    ∑ w ∈ neighbors M.graph v.val, f w =
      (if M.graph.Adj v.val r then f r else 0) +
      ∑ w ∈ neighbors (M.graph.induce {u | u ≠ r}) v, f w.val := by
  classical
  simp only [neighbors, Finset.sum_filter, SimpleGraph.induce_adj]
  exact Fintype.sum_eq_add_sum_subtype_ne _ r

open Classical in
/-- Each incidence to the removed vertex is replaced by a fixed slot at
its surviving endpoint. All pre-existing slots and marks are retained. -/
noncomputable def deleteVertex (input : Away r → Bool) : BoundaryModel (Away r) where
  graph := M.graph.induce {v | v ≠ r}
  fixed v b := M.fixed v.val b + if M.graph.Adj v.val r ∧ b = input v then 1 else 0
  marked v := M.marked v.val
  opposite v := M.opposite v.val
  marked_le v := M.marked_le v.val
  budget v := by
    have cnt := M.sum_neighbors_away r v (fun _ => 1)
    simp only [Finset.sum_const, smul_eq_mul, mul_one] at cnt
    have old := M.budget v.val
    by_cases e : M.graph.Adj v.val r <;> cases input v <;> simp [e] at cnt ⊢ <;> omega

noncomputable def extendAt (s : Bool) (h : Away r → Bool) (v : V) : Bool := by
  classical
  exact if hv : v = r then s else h ⟨v, hv⟩

omit [Fintype V] in
@[simp] theorem extendAt_root (s : Bool) (h : Away r → Bool) : extendAt r s h r = s := by
  simp [extendAt]

omit [Fintype V] in
@[simp] theorem extendAt_away (s : Bool) (h : Away r → Bool) (v : Away r) :
    extendAt r s h v.val = h v := by simp [extendAt, v.property]

open Classical in
theorem deleteVertex_degree (h : V → Bool) (v : Away r) :
    (M.deleteVertex r (fun _ => h r)).monoDegree (fun w => h w.val) v = M.monoDegree h v.val := by
  unfold monoDegree inside
  rw [M.sum_neighbors_away r v (fun w => same (h v.val) (h w))]
  simp only [deleteVertex]
  by_cases e : M.graph.Adj v.val r
  · simp only [e, true_and, ite_true, same, Nat.add_left_comm, Nat.add_comm, Nat.add_assoc]
    congr!
  · simp only [e, false_and, ite_false, Nat.add_zero, Nat.zero_add]
    congr!

open Classical in
theorem extendAt_sum (s : Bool) (input : Away r → Bool) (h : Away r → Bool) :
    M.weightedSum (extendAt r s h) =
      M.weight r * spin s + (M.deleteVertex r input).weightedSum h := by
  classical
  unfold weightedSum
  rw [Fintype.sum_eq_add_sum_subtype_ne _ r]
  simp only [extendAt_root, extendAt_away]
  rfl

open Classical in
/-- Under constant boundary input, the only possible defect in the extension
is the restored vertex. -/
theorem extendAt_degree (s : Bool) (h : Away r → Bool) (v : Away r) :
    M.monoDegree (extendAt r s h) v.val = (M.deleteVertex r (fun _ => s)).monoDegree h v := by
  simpa only [extendAt_root, extendAt_away] using
    (M.deleteVertex_degree r (extendAt r s h) v).symm

open Classical in
/-- After changing at most one relevant boundary input, the induced model
admits a repair with the signed two-point correction at that input. -/
theorem change_input (a b : Away r → Bool) (u : Away r)
    (agree : ∀ v : Away r, v ≠ u → M.graph.Adj v.val r → a v = b v)
    (f : Good (M.deleteVertex r a)) :
    ∃ g : Good (M.deleteVertex r b),
      (M.deleteVertex r b).weightedSum g.val = (M.deleteVertex r a).weightedSum f.val ∨
      (M.deleteVertex r b).weightedSum g.val =
        (M.deleteVertex r a).weightedSum f.val - 2 * spin (b u) := by
  classical
  let N := M.deleteVertex r b
  have old := f.property
  have unchanged (v : Away r) (sameInput : M.graph.Adj v.val r → a v = b v) :
      N.monoDegree f.val v ≤ 1 := by
    have hv := old v
    by_cases edge : M.graph.Adj v.val r
    · simpa only [N, monoDegree, inside, deleteVertex, sameInput edge] using hv
    · simpa [N, monoDegree, inside, deleteVertex, edge] using hv
  have elsewhere (v : Away r) (ne : v ≠ u) := unchanged v (agree v ne)
  by_cases root : N.monoDegree f.val u ≤ 1
  · refine ⟨⟨f.val, fun v => ?_⟩, Or.inl rfl⟩
    by_cases e : v = u
    · simpa only [e] using root
    · exact elsewhere v e
  · have color : f.val u = b u := by
      by_contra different
      apply root
      have hv := old u
      simp only [N, monoDegree, inside, deleteVertex, different, and_false, ite_false,
        Nat.add_zero] at hv ⊢
      omega
    obtain ⟨g, _, ok, _, delta⟩ := N.single_repair f.val u (by omega) elsewhere
    exact ⟨⟨g, ok⟩, by simpa only [color, N, weightedSum, weight, deleteVertex] using delta⟩

open Classical in
/-- When the removed vertex has two neighbors, change the two incidences
in succession. All corrections use the same new sign. -/
theorem change_two_inputs (u v : Away r)
    (cover : ∀ w : Away r, M.graph.Adj w.val r → w = u ∨ w = v)
    (s : Bool) (f : Good (M.deleteVertex r (fun _ => !s))) :
    ∃ g : Good (M.deleteVertex r (fun _ => s)),
      let diff := (M.deleteVertex r (fun _ => s)).weightedSum g.val -
        (M.deleteVertex r (fun _ => !s)).weightedSum f.val
      diff = 0 ∨ diff = -2 * spin s ∨ diff = -4 * spin s := by
  classical
  let mid (w : Away r) := if w = u then s else !s
  obtain ⟨k, first⟩ := M.change_input r (fun _ => !s) mid u
    (fun w ne _ => by simp [mid, ne]) f
  obtain ⟨g, second⟩ := M.change_input r mid (fun _ => s) v (fun w ne adj => by
    have eq := (cover w adj).resolve_right ne
    simp [mid, eq]) k
  refine ⟨g, ?_⟩
  dsimp only
  have hu : mid u = s := by simp [mid]
  rw [hu] at first
  omega

end QuasiBisection.BoundaryModel
