module

public import QuasiBisection.PackingColor

/-! Lifting the two marked edges of a prefix to the full subcubic graph. -/

@[expose] public section

namespace QuasiBisection

open CycleOrder BoundaryModel

variable {V : Type*} [Fintype V] {G : SimpleGraph V} {F : Finset (Finset V)}

/-- Fill each missing incidence with an unmarked opposite slot, preserving all vertex weights. -/
noncomputable def subcubicModel (subcubic : Subcubic G) : BoundaryModel V where
  graph := G
  fixed _ _ := 0
  marked _ := 0
  opposite v := 3 - (neighbors G v).card
  marked_le _ := Nat.zero_le _
  budget v := Nat.add_sub_of_le (subcubic v)

open Classical in
theorem subcubicModel_degree (subcubic : Subcubic G) (h : V → Bool) (v : V) :
    (subcubicModel subcubic).monoDegree h v =
      ((neighbors G v).filter (fun u => h u = h v)).card := by
  classical
  simp only [monoDegree, inside, subcubicModel, Nat.add_zero, Finset.card_filter, same,
    eq_comm (a := h v)]

@[simp] theorem subcubicModel_sum (subcubic : Subcubic G) (h : V → Bool) :
    (subcubicModel subcubic).weightedSum h = imbalance h := by
  simp [weightedSum, weight, subcubicModel, imbalance]

private theorem degree_bound (subcubic : Subcubic G) (h : V → Bool) {v a b : V}
    (ha : G.Adj v a) (hb : G.Adj v b) (ne : a ≠ b) :
    (subcubicModel subcubic).monoDegree h v ≤ 1 + same (h v) (h a) + same (h v) (h b) := by
  classical
  let N := neighbors G v
  have mem {w : V} (e : G.Adj v w) : w ∈ N := Finset.mem_filter.mpr ⟨Finset.mem_univ _, e⟩
  have ma := mem ha
  have mb := Finset.mem_erase.mpr ⟨ne.symm, mem hb⟩
  have card : ((N.erase a).erase b).card ≤ 1 := by
    rw [Finset.card_erase_of_mem mb, Finset.card_erase_of_mem ma]
    change (neighbors G v).card - 1 - 1 ≤ 1
    have := subcubic v
    omega
  have bound : (∑ w ∈ (N.erase a).erase b, same (h v) (h w)) ≤ 1 := by
    calc
      _ ≤ ∑ _w ∈ (N.erase a).erase b, (1 : ℕ) :=
        Finset.sum_le_sum (fun w _ => by unfold same; split <;> decide)
      _ ≤ 1 := by simpa using card
  change (∑ u ∈ N, same (h v) (h u)) + 0 ≤ _
  rw [← Finset.add_sum_erase _ _ ma, ← Finset.add_sum_erase _ _ mb]
  omega

namespace EvenPacking

variable (P : EvenPacking G F)

private theorem index_bound (subcubic : Subcubic G) (k : F → ℕ) (r : leftover F → Bool)
    (T : F) (i : Fin (P.order T).size) :
    let h := P.coloring k r
    (subcubicModel subcubic).monoDegree h (P.atPos ⟨T,i⟩) ≤ 1 +
      same (prefixColor (k T) i.val) (prefixColor (k T) (prev i).val) +
      same (prefixColor (k T) i.val) (prefixColor (k T) (next i).val) := by
  have left := ((P.order T).edge (prev i)).symm
  rw [next_prev] at left
  have distinct : P.atPos ⟨T, prev i⟩ ≠ P.atPos ⟨T, next i⟩ := by
    intro eq
    exact prev_ne_next (P.order T).three i ((P.order T).vertex.injective (Subtype.ext eq))
  simpa only [coloring_right] using
    (degree_bound subcubic (P.coloring k r) (v := P.atPos ⟨T,i⟩)
      (a := P.atPos ⟨T, prev i⟩) (b := P.atPos ⟨T, next i⟩) left ((P.order T).edge i) distinct)

private theorem degree_settled (subcubic : Subcubic G) (k : F → ℕ) (r : leftover F → Bool)
    (T : F) (i : Fin (P.order T).size) (done : P.Settled k T) :
    (subcubicModel subcubic).monoDegree (P.coloring k r) (P.atPos ⟨T,i⟩) ≤ 1 := by
  have diff (j : Fin (P.order T).size) :
      prefixColor (k T) j.val ≠ prefixColor (k T) (next j).val := by
    intro eq
    have := prefix_match (P.order T).even _ j eq
    rcases done with h | h <;> omega
  have before := (diff (prev i)).symm
  rw [next_prev] at before
  simpa only [same, before, diff i, ite_false, Nat.add_zero] using P.index_bound subcubic k r T i

/-- For a proper prefix the two exceptional forward edges enter positions
zero and k. Count each of them at most once at each incident vertex. -/
private theorem degree_partial (subcubic : Subcubic G) (k : F → ℕ) (r : leftover F → Bool)
    (T : F) (pos : 0 < k T) (lt : k T < (P.order T).size) (i : Fin (P.order T).size) :
    let z : Fin (P.order T).size := ⟨0, by omega⟩
    let q : Fin (P.order T).size := ⟨k T, lt⟩
    let v := P.atPos ⟨T, i⟩
    (subcubicModel subcubic).monoDegree (P.coloring k r) v ≤
      1 + endpoint (P.atPos ⟨T, prev q⟩) (P.atPos ⟨T, q⟩) v +
        endpoint (P.atPos ⟨T, prev z⟩) (P.atPos ⟨T, z⟩) v := by
  classical
  dsimp only
  apply (P.index_bound subcubic k r T i).trans
  have samePos (a b : Fin (P.order T).size) :
      P.atPos ⟨T, a⟩ = P.atPos ⟨T, b⟩ ↔ a.val = b.val :=
    ⟨fun e => congrArg Fin.val ((P.order T).vertex.injective (Subtype.ext e)),
      fun e => congrArg (fun j => P.atPos ⟨T,j⟩) (Fin.ext e)⟩
  have before (e : prefixColor (k T) i.val = prefixColor (k T) (prev i).val) :
      i.val = 0 ∨ i.val = k T := by
    have h := prefix_match (P.order T).even _ (prev i) (by simpa only [next_prev] using e.symm)
    simpa only [next_prev] using h.2.2
  have after := fun e => (prefix_match (P.order T).even (k T) i e).2.2
  simp only [endpoint, samePos]
  change _ ≤ 1 + (if i.val = (prev (⟨k T, lt⟩ : Fin _)).val ∨ i.val = k T then 1 else 0) +
    (if i.val = (prev (⟨0, by omega⟩ : Fin (P.order T).size)).val ∨ i.val = 0 then 1 else 0)
  rw [show (prev (⟨k T, lt⟩ : Fin _)).val = k T - 1 by simp [prev_val, pos.ne'],
    show (prev (⟨0, by omega⟩ : Fin (P.order T).size)).val = (P.order T).size - 1 by
      simp [prev_val]]
  unfold same
  have size := (P.order T).three
  have after' : prefixColor (k T) i.val = prefixColor (k T) (next i).val →
      i.val = (P.order T).size - 1 ∨ i.val = k T - 1 := by
    intro e
    have h := after e
    simp only [next_val] at h
    have := i.isLt
    split_ifs at h <;> simp only [false_or] at h <;> omega
  split_ifs
  all_goals try have hb := before (by assumption)
  all_goals try have ha := after' (by assumption)
  all_goals omega

open Classical in
abbrev ResidueGood (subcubic : Subcubic G) (k : F → ℕ) :=
  Good (residueModel G (leftover F) subcubic (P.coloring k (fun _ => false)))

omit [Fintype V] in
private theorem exterior_color (k : F → ℕ) (r : leftover F → Bool) (v : V)
    (out : v ∉ leftover F) : P.coloring k r v = P.coloring k (fun _ => false) v := by
  obtain ⟨w | p, rfl⟩ := P.coordinates.surjective v
  · exact (out w.property).elim
  · simp

open Classical in
theorem coloring_degree_left (subcubic : Subcubic G) (k : F → ℕ) (r : leftover F → Bool)
    (v : leftover F) : (subcubicModel subcubic).monoDegree (P.coloring k r) v.val =
      (residueModel G (leftover F) subcubic (P.coloring k (fun _ => false))).monoDegree r v := by
  classical
  rw [subcubicModel_degree, ← residueModel_degree G (leftover F) subcubic _ v]
  have ext (w : {x // x ∉ leftover F}) := P.exterior_color k r w.val w.property
  simp only [monoDegree, inside, residueModel, coloring_left, ext]

theorem coloring_good_left (subcubic : Subcubic G) (k : F → ℕ) (r : P.ResidueGood subcubic k)
    (v : leftover F) : (subcubicModel subcubic).monoDegree (P.coloring k r.val) v.val ≤ 1 :=
  (P.coloring_degree_left subcubic k r.val v).le.trans (r.property v)

def HasQuasiBisection (G : SimpleGraph V) : Prop :=
  ∃ h : V → Bool, Admissible G h ∧ (imbalance h).natAbs ≤ 2

open Classical in
theorem finish_settled (subcubic : Subcubic G) (k : F → ℕ)
    (done : ∀ T, P.Settled k T)
    (r : P.ResidueGood subcubic k) (small : (imbalance r.val).natAbs ≤ 2) :
    HasQuasiBisection G := by
  classical
  refine ⟨P.coloring k r.val, fun v => ?_, ?_⟩
  · rw [← subcubicModel_degree subcubic]
    obtain ⟨w | ⟨T, i⟩, rfl⟩ := P.coordinates.surjective v
    · exact P.coloring_good_left subcubic k r w
    · exact P.degree_settled subcubic k r.val T i (done T)
  · simpa only [P.coloring_sum, fun T => P.settled_contribution (done T),
      Finset.sum_const_zero, add_zero] using small

open Classical in
/-- On a proper prefix, its two boundary edges account for all excess
monochromatic incidences. Their signs also account for the full sum at P = 0. -/
theorem finish_partial (subcubic : Subcubic G) (k : F → ℕ) (T : F)
    (others : ∀ U, U ≠ T → P.Settled k U) (pos : 0 < k T) (lt : k T < (P.order T).size)
    (r : P.ResidueGood subcubic k) (zero : imbalance r.val = 0) : HasQuasiBisection G := by
  classical
  let n := (P.order T).size
  let z : Fin n := ⟨0, by omega⟩
  let q : Fin n := ⟨k T, lt⟩
  let v (i : Fin n) := P.atPos ⟨T, i⟩
  let h := P.coloring k r.val
  have adj (i : Fin n) : G.Adj (v (prev i)) (v i) := by
    have e := (P.order T).edge (prev i)
    rw [next_prev] at e
    exact e
  have colors (i : Fin n) : h (v i) = prefixColor (k T) i.val := P.coloring_right k r.val ⟨T,i⟩
  have neven := (P.order T).even
  obtain ⟨m, hm⟩ := neven
  change n = m + m at hm
  have eq₁ : h (v (prev z)) = false := by
    rw [colors, prev_val]
    simp only [z, ite_true, prefixColor]
    simp [show ¬ n - 1 < k T by change k T < n at lt; omega, show (n - 1) % 2 ≠ 0 by omega]
  have eq₂ : h (v z) = false := by simp [colors, z, prefixColor, pos]
  have eq₃ : h (v (prev q)) = decide (k T % 2 = 0) := by
    rw [colors, prev_val]
    simp only [q, pos.ne', ite_false, prefixColor, show k T - 1 < k T by omega, ite_true]
    by_cases e : k T % 2 = 0 <;> simp [e, show (k T - 1) % 2 = (1 - k T % 2) by omega]
    omega
  have eq₄ : h (v q) = decide (k T % 2 = 0) := by simp [colors, q, prefixColor]
  have total : (subcubicModel subcubic).weightedSum h =
      spin false + spin (decide (k T % 2 = 0)) := by
    rw [subcubicModel_sum, show h = P.coloring k r.val from rfl, P.coloring_sum,
      Finset.sum_eq_single T, zero, zero_add]
    · rw [Nat.min_eq_left lt.le]
      split_ifs <;> simp_all [spin]
    · intro U _ ne
      exact P.settled_contribution (others U ne)
    · simp
  have cap (x : V) : (subcubicModel subcubic).monoDegree h x ≤
      1 + endpoint (v (prev q)) (v q) x + endpoint (v (prev z)) (v z) x := by
    obtain ⟨w | ⟨U, i⟩, rfl⟩ := P.coordinates.surjective x
    · have := P.coloring_good_left subcubic k r w
      exact this.trans (by omega)
    · by_cases eq : U = T
      · subst U
        exact P.degree_partial subcubic k r.val T pos lt i
      · exact (P.degree_settled subcubic k r.val U i (others U eq)).trans (by omega)
  obtain ⟨g, good, small⟩ := (subcubicModel subcubic).repair_two_edges (fun _ => rfl) h
    _ _ _ _ (adj z) (adj q) _ _ eq₁ eq₂ eq₃ eq₄ cap total
  exact ⟨g, fun x => by simpa only [subcubicModel_degree] using good x,
    by simpa only [subcubicModel_sum] using small⟩

end EvenPacking
end QuasiBisection
