module

public import QuasiBisection.ComponentSpectrum

/-! Fixed boundary colors on an induced residue of a finite subcubic graph. -/

@[expose] public section

namespace QuasiBisection

open BoundaryModel

variable {V : Type*} [Fintype V] (G : SimpleGraph V) (W : Set V)
  [DecidablePred (· ∈ W)]

open Classical in
private theorem split_neighbors (v : W) (f : V → ℕ) :
    ∑ u ∈ neighbors G v.val, f u =
      (∑ u ∈ neighbors (G.induce W) v, f u.val) +
      ∑ u : {x // x ∉ W}, if G.Adj v.val u.val then f u.val else 0 := by
  simp only [neighbors, Finset.sum_filter, SimpleGraph.induce_adj]
  exact (Fintype.sum_subtype_add_sum_subtype (· ∈ W)
    (fun u => if G.Adj v.val u then f u else 0)).symm

open Classical in
/-- Every edge leaving the residue contributes one slot with its actual
exterior color, even when several slots at one vertex have the same color. -/
noncomputable def residueModel (subcubic : Subcubic G) (color : V → Bool) : BoundaryModel W where
  graph := G.induce W
  marked _ := 0
  opposite v := 3 - (neighbors G v.val).card
  marked_le _ := Nat.zero_le _
  fixed v b := ∑ u : {x // x ∉ W}, if G.Adj v.val u.val then same b (color u.val) else 0
  budget v := by
    have split := split_neighbors G W v (fun _ => 1)
    simp only [Finset.sum_const, smul_eq_mul, mul_one] at split
    suffices count : (neighbors (G.induce W) v).card +
        (∑ u : {x // x ∉ W}, if G.Adj v.val u.val then same true (color u.val) else 0) +
        (∑ u : {x // x ∉ W}, if G.Adj v.val u.val then same false (color u.val) else 0) =
        (neighbors G v.val).card by
      rw [count]
      exact Nat.add_sub_of_le (subcubic v.val)
    rw [Nat.add_assoc, ← Finset.sum_add_distrib]
    convert split.symm using 2
    apply Finset.sum_congr rfl
    intro u _
    by_cases adj : G.Adj v.val u.val <;> cases color u.val <;> simp [adj, same]

open Classical in
/-- Restriction counts precisely the monochromatic neighbors in the full graph. -/
theorem residueModel_degree (subcubic : Subcubic G) (color : V → Bool) (v : W) :
    (residueModel G W subcubic color).monoDegree (fun u => color u.val) v =
      ((neighbors G v.val).filter (fun u => color u = color v.val)).card := by
  classical
  rw [Finset.card_filter]
  simpa only [monoDegree, inside, residueModel, same, eq_comm (a := color v.val)] using
    (split_neighbors G W v (fun u => same (color v.val) (color u))).symm

@[simp] theorem residueModel_sum (subcubic : Subcubic G) (color : V → Bool) (h : W → Bool) :
    (residueModel G W subcubic color).weightedSum h = imbalance h := by
  simp [weightedSum, weight, residueModel, imbalance]

omit [DecidablePred (· ∈ W)] in
/-- Extend any exterior assignment, satisfying all degree requirements on the residue. -/
theorem exists_residue_coloring (subcubic : Subcubic G) (color : V → Bool) :
    ∃ h : V → Bool, (∀ v ∉ W, h v = color v) ∧
      ∀ v ∈ W, ((neighbors G v).filter (fun u => h u = h v)).card ≤ 1 := by
  classical
  let M := residueModel G W subcubic color
  obtain ⟨g, _, good⟩ := M.repair_exists (fun v => color v.val)
  let h (v : V) := if hv : v ∈ W then g ⟨v, hv⟩ else color v
  have outside (v : V) (hv : v ∉ W) : h v = color v := dite_eq_right hv
  refine ⟨h, outside, fun v hv => ?_⟩
  rw [← residueModel_degree G W subcubic h ⟨v, hv⟩]
  have inside' (u : W) : h u.val = g u := dite_eq_left u.property
  have outside' (u : {x // x ∉ W}) : h u.val = color u.val := outside _ u.property
  simpa only [M, monoDegree, inside, residueModel, inside', outside', inside' ⟨v, hv⟩] using
    good ⟨v, hv⟩

/-- At a fixed exterior coloring the whole (possibly disconnected) residue
has gap at most four in the ordinary, unweighted sum. -/
theorem residue_step_four (subcubic : Subcubic G) (color : V → Bool)
    (cactus : CactusCycles (G.induce W)) :
    Bridge.HasStep 4 (fun h : Good (residueModel G W subcubic color) => imbalance h.val) := by
  simpa only [spectralStep, residueModel_sum] using
    (residueModel G W subcubic color).cactus_forest_step_four cactus

/-- When just one exterior sign changes, at most one residual neighbor can
need repair. The correction has the sign prescribed by the new exterior input. -/
theorem change_exterior (subcubic : Subcubic G) (a b : V → Bool) (x : V)
    (unchanged : ∀ z, z ≠ x → a z = b z)
    (unique : ∀ v w : W, G.Adj v.val x → G.Adj w.val x → v = w)
    (f : Good (residueModel G W subcubic a)) :
    ∃ g : Good (residueModel G W subcubic b),
      imbalance g.val = imbalance f.val ∨ imbalance g.val = imbalance f.val - 2 * spin (b x) := by
  classical
  let N := residueModel G W subcubic b
  have safe (v : W) (ok : ¬ G.Adj v.val x ∨ f.val v ≠ b x) : N.monoDegree f.val v ≤ 1 := by
    apply le_trans _ (f.property v)
    apply Nat.add_le_add_left
    apply Finset.sum_le_sum
    intro z _
    by_cases edge : G.Adj v.val z.val
    · by_cases eq : z.val = x
      · have ne := ok.resolve_left (not_not_intro (eq ▸ edge))
        simp [eq, same, ne]
      · simp [unchanged _ eq]
    · simp [edge]
  by_cases good : ∀ v, N.monoDegree f.val v ≤ 1
  · exact ⟨⟨f.val, good⟩, Or.inl rfl⟩
  obtain ⟨r, bad⟩ := Classical.not_forall.mp good
  have adj : G.Adj r.val x := by
    by_contra h
    exact bad (safe r (.inl h))
  have sign : f.val r = b x := by
    by_contra h
    exact bad (safe r (.inr h))
  obtain ⟨g, _, valid, _, diff⟩ := N.single_repair f.val r (by omega)
    (fun v ne => safe v (.inl (fun hv => ne (unique _ _ hv adj))))
  exact ⟨⟨g, valid⟩, by simpa only [N, residueModel_sum, sign] using diff⟩

end QuasiBisection
