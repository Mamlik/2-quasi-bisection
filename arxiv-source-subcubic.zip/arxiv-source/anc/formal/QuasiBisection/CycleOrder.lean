module

public import QuasiBisection.EvenCyclePacking
public import QuasiBisection.MarkedEdges
import Mathlib.Algebra.BigOperators.Fin

/-! A cyclic order on each packed support and its alternating prefix inversions. -/

@[expose] public section

namespace QuasiBisection

variable {V : Type*} {G : SimpleGraph V} {S : Finset V}

namespace CycleOrder

def next {n : ℕ} (i : Fin n) : Fin n :=
  if h : i.val + 1 < n then ⟨i.val + 1, h⟩ else ⟨0, by omega⟩

def prev {n : ℕ} (i : Fin n) : Fin n :=
  if i.val = 0 then ⟨n - 1, by have := i.isLt; omega⟩ else ⟨i.val - 1, by omega⟩

theorem next_val {n : ℕ} (i : Fin n) :
    (next i).val = if i.val + 1 < n then i.val + 1 else 0 := by
  unfold next
  split <;> rfl

theorem prev_val {n : ℕ} (i : Fin n) :
    (prev i).val = if i.val = 0 then n - 1 else i.val - 1 := by
  unfold prev
  split <;> rfl

@[simp] theorem next_prev {n : ℕ} (i : Fin n) : next (prev i) = i := by
  apply Fin.ext
  simp only [next_val, prev_val]
  split_ifs <;> omega

@[simp] theorem prev_next {n : ℕ} (i : Fin n) : prev (next i) = i := by
  apply Fin.ext
  have := i.isLt
  simp only [prev_val, next_val]
  split_ifs <;> first | contradiction | omega

theorem prev_ne_next {n : ℕ} (big : 3 ≤ n) (i : Fin n) : prev i ≠ next i := by
  intro eq
  have val := congrArg Fin.val eq
  unfold prev next at val
  split at val <;> split at val <;> simp_all <;> omega

end CycleOrder

/-- The cyclic order includes only the edges of the chosen walk. Chords may exist. -/
structure CycleOrder (G : SimpleGraph V) (S : Finset V) where
  size : ℕ
  three : 3 ≤ size
  even : Even size
  vertex : Fin size ≃ S
  edge : ∀ i, G.Adj (vertex i).val (vertex (CycleOrder.next i)).val

namespace CycleOrder

open Classical in
noncomputable def ofSupport (support : EvenCycleSupport G S) : CycleOrder G S := by
  classical
  apply Classical.choice
  obtain ⟨x, p, hp, even, rfl⟩ := support
  let f (i : Fin p.length) : p.support.toFinset :=
    ⟨p.getVert i.val, List.mem_toFinset.mpr (p.getVert_mem_support _)⟩
  have inj : Function.Injective f := by
    intro i j eq
    exact Fin.ext (hp.getVert_injOn' (by change i.val ≤ _; omega)
      (by change j.val ≤ _; omega) (congrArg Subtype.val eq))
  have surj : Function.Surjective f := by
    intro v
    obtain ⟨i, hi, le⟩ := p.mem_support_iff_exists_getVert.mp (List.mem_toFinset.mp v.property)
    by_cases lt : i < p.length
    · exact ⟨⟨i, lt⟩, Subtype.ext hi⟩
    have he : i = p.length := by omega
    exact ⟨⟨0, by have := hp.three_le_length; omega⟩, Subtype.ext (by simpa [f, he] using hi)⟩
  refine ⟨⟨_, hp.three_le_length, even, Equiv.ofBijective f ⟨inj, surj⟩, fun i => ?_⟩⟩
  change G.Adj (p.getVert i.val) (p.getVert (next i).val)
  have adj := p.adj_getVert_succ i.isLt
  by_cases lt : i.val + 1 < p.length
  · simpa [next, lt] using adj
  · simpa [next, lt, show i.val + 1 = p.length by omega] using adj

/-- Invert the first k vertices of the original alternating coloring. -/
def prefixColor (k i : ℕ) : Bool := if i < k then !(decide (i % 2 = 0)) else decide (i % 2 = 0)

theorem prefix_sum (n k : ℕ) :
    (∑ i ∈ Finset.range n, spin (prefixColor k i)) =
      (if n % 2 = 0 then 0 else 1) - 2 * (if min k n % 2 = 0 then 0 else 1) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ, ih]
    by_cases lt : n < k
    · simp only [prefixColor, lt, ite_true, Nat.min_eq_right (by omega : n ≤ k),
        Nat.min_eq_right (by omega : n + 1 ≤ k), spin]
      split_ifs <;> simp_all <;> omega
    · simp only [prefixColor, lt, ite_false, Nat.min_eq_left (by omega : k ≤ n),
        Nat.min_eq_left (by omega : k ≤ n + 1), spin, decide_eq_true_eq]
      split_ifs <;> omega

theorem prefix_imbalance {n : ℕ} (even : Even n) (k : ℕ) :
    (∑ i : Fin n, spin (prefixColor k i.val)) = if min k n % 2 = 0 then 0 else -2 := by
  obtain ⟨m, hm⟩ := even
  rw [Fin.sum_univ_eq_sum_range (fun i => spin (prefixColor k i)) n, prefix_sum]
  split_ifs <;> omega

/-- A monochromatic forward edge must enter the first vertex or the cut.
Both edges are absent for an empty or a completely inverted prefix. -/
theorem prefix_match {n : ℕ} (even : Even n) (k : ℕ) (i : Fin n)
    (matchColor : prefixColor k i.val = prefixColor k (next i).val) :
    0 < k ∧ k < n ∧ ((next i).val = 0 ∨ (next i).val = k) := by
  obtain ⟨m, hm⟩ := even
  simp only [next_val, prefixColor] at matchColor ⊢
  split_ifs at matchColor <;> simp_all <;> omega

end CycleOrder
end QuasiBisection
